<?php
// EFA Hazır Giyim — yönetim paneli işlemleri (kaydet, fotoğraf yükle/sil)
declare(strict_types=1);
define('EFA', 1);
require __DIR__ . '/inc/lib.php';
sec_headers();
header('Content-Type: application/json; charset=utf-8');
start_session();

function out(int $code, array $d): void { http_response_code($code); echo json_encode($d, JSON_UNESCAPED_UNICODE); exit; }
function fail_msg(int $code, string $m): void { out($code, ['ok' => false, 'error' => $m]); }

if (!logged_in() || config()['must']) fail_msg(401, 'Oturumunuz kapandı. Lütfen sayfayı yenileyip tekrar giriş yapın.');
if ($_SERVER['REQUEST_METHOD'] !== 'POST') fail_msg(405, 'Geçersiz istek.');
if (!hash_equals((string)$_SESSION['csrf'], (string)($_SERVER['HTTP_X_CSRF'] ?? ''))) fail_msg(403, 'Güvenlik anahtarı geçersiz. Sayfayı yenileyin.');
$origin = (string)($_SERVER['HTTP_ORIGIN'] ?? '');
if ($origin !== '') {
    $oh = strtolower((string)parse_url($origin, PHP_URL_HOST));
    $hh = strtolower(preg_replace('/:\d+$/', '', (string)($_SERVER['HTTP_HOST'] ?? '')));
    if ($oh !== $hh) fail_msg(403, 'Geçersiz kaynak.');
}

function load_content(): array { return jread(CONTENT_FILE, []); }
function save_content(array $c): int {
    ensure_dir(dirname(CONTENT_FILE), false);
    $c['v'] = time();
    jwrite(CONTENT_FILE, $c, false);
    return $c['v'];
}

// Gelen içeriği yalnız izin verilen alanlarla, temizlenmiş olarak alır
function clean_content(array $in): array {
    $o = [];
    $t = [];
    foreach ((array)($in['t'] ?? []) as $k => $v) {
        if (count($t) >= 3000) break;
        if (!is_string($k) || !preg_match('/^h:[0-9a-f]{8}$/', $k) || !is_array($v)) continue;
        $e = ['tr' => txt($v['tr'] ?? '', 2000), 'en' => txt($v['en'] ?? '', 2000)];
        if ($e['tr'] !== '' || $e['en'] !== '') $t[$k] = $e;
    }
    if ($t) $o['t'] = $t;
    $n = [];
    foreach ((array)($in['n'] ?? []) as $k => $v) {
        if (!is_string($k) || !preg_match('/^[a-z0-9_]{1,20}$/', $k)) continue;
        $v = txt($v, 40);
        if ($v !== '') $n[$k] = $v;
    }
    if ($n) $o['n'] = $n;
    $c = (array)($in['c'] ?? []);
    $cc = [];
    $ph = txt($c['phone'] ?? '', 40); if ($ph !== '') $cc['phone'] = $ph;
    $em = txt($c['email'] ?? '', 120); if ($em !== '' && filter_var($em, FILTER_VALIDATE_EMAIL)) $cc['email'] = $em;
    $wa = preg_replace('/\D/', '', (string)($c['wa'] ?? '')); if ($wa !== '' && strlen($wa) >= 10 && strlen($wa) <= 15) $cc['wa'] = $wa;
    $ad = txt($c['addr'] ?? '', 300); if ($ad !== '') $cc['addr'] = $ad;
    if ($cc) $o['c'] = $cc;
    $st = [];
    foreach (STEP_KEYS as $k) {
        $s = $in['steps'][$k] ?? null; if (!is_array($s)) continue;
        foreach (['tr', 'en'] as $l) {
            $x = $s[$l] ?? null; if (!is_array($x)) continue;
            $e = [];
            $tt = txt($x['t'] ?? '', 80); if ($tt !== '') $e['t'] = $tt;
            $ld = txt($x['lead'] ?? '', 300); if ($ld !== '') $e['lead'] = $ld;
            $p = array_values(array_filter(array_map(function ($v) { return txt($v, 1500); }, array_slice((array)($x['p'] ?? []), 0, 6)), 'strlen'));
            if ($p) $e['p'] = $p;
            $b = array_values(array_filter(array_map(function ($v) { return txt($v, 120); }, array_slice((array)($x['b'] ?? []), 0, 8)), 'strlen'));
            if (count($b) >= 3) $e['b'] = $b;
            if ($e) $st[$k][$l] = $e;
        }
    }
    if ($st) $o['steps'] = $st;
    $dc = [];
    foreach (DOC_KEYS as $k) {
        $s = $in['docs'][$k] ?? null; if (!is_array($s)) continue;
        foreach (['tr', 'en'] as $l) {
            $x = $s[$l] ?? null; if (!is_array($x)) continue;
            $e = [];
            $tt = txt($x['t'] ?? '', 120); if ($tt !== '') $e['t'] = $tt;
            $hh = txt($x['h'] ?? '', 20000); if ($hh !== '') $e['h'] = $hh;
            if ($e) $dc[$k][$l] = $e;
        }
    }
    if ($dc) $o['docs'] = $dc;
    if (isset($in['refs']) && is_array($in['refs'])) {
        $rf = [];
        foreach (array_slice($in['refs'], 0, 80) as $r) {
            if (!is_array($r)) continue;
            $nm = txt($r['name'] ?? '', 60); if ($nm === '') continue;
            $e = ['name' => $nm];
            $im = (string)($r['img'] ?? '');
            if (preg_match('/^[a-z0-9-]{1,60}\.(png|jpg)$/', $im)) $e['img'] = $im;
            $rf[] = $e;
        }
        if ($rf) $o['refs'] = $rf;
    }
    return $o;
}

// Fotoğraf yuvası: yalnız sabit klasör ve dosya adları (kullanıcı yol veremez)
function slot(): array {
    $type = (string)($_POST['type'] ?? '');
    if ($type === 'step') {
        $k = (string)($_POST['key'] ?? ''); $n = (int)($_POST['n'] ?? 0);
        if (!in_array($k, STEP_KEYS, true) || $n < 1 || $n > 3) fail_msg(400, 'Geçersiz bölüm.');
        return ['dir' => 'assets/img/bolumler', 'file' => "$k-$n.jpg", 'max' => 1600, 'fmt' => 'jpg'];
    }
    if ($type === 'product') {
        $k = (string)($_POST['key'] ?? '');
        if (!in_array($k, PROD_KEYS, true)) fail_msg(400, 'Geçersiz ürün.');
        return ['dir' => 'assets/img/urunler', 'file' => "$k.jpg", 'max' => 1200, 'fmt' => 'jpg'];
    }
    if ($type === 'ref') {
        $name = txt($_POST['name'] ?? '', 60);
        if ($name === '') fail_msg(400, 'Önce marka adını yazın.');
        return ['dir' => 'assets/img/referanslar', 'file' => slugify($name) . '.png', 'max' => 600, 'fmt' => 'png'];
    }
    fail_msg(400, 'Geçersiz istek.');
    return [];
}

// Telefon fotoğraflarının yönünü düzeltir
function fix_orientation($im, string $path) {
    if (!function_exists('exif_read_data')) return $im;
    $ex = @exif_read_data($path);
    $o = (int)($ex['Orientation'] ?? 1);
    if ($o === 3) $im = imagerotate($im, 180, 0);
    elseif ($o === 6) $im = imagerotate($im, -90, 0);
    elseif ($o === 8) $im = imagerotate($im, 90, 0);
    return $im;
}

function process_upload(array $s): void {
    $f = $_FILES['f'] ?? null;
    if (!is_array($f) || ($f['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK) {
        $e = (int)($f['error'] ?? 4);
        fail_msg(400, $e === UPLOAD_ERR_INI_SIZE || $e === UPLOAD_ERR_FORM_SIZE ? 'Dosya çok büyük (en fazla 10 MB).' : 'Dosya yüklenemedi.');
    }
    if ((int)$f['size'] > 10 * 1024 * 1024) fail_msg(400, 'Dosya çok büyük (en fazla 10 MB).');
    if (!is_uploaded_file((string)$f['tmp_name'])) fail_msg(400, 'Dosya yüklenemedi.');
    $info = @getimagesize((string)$f['tmp_name']);
    if (!$info || !in_array($info[2], [IMAGETYPE_JPEG, IMAGETYPE_PNG, IMAGETYPE_WEBP], true)) fail_msg(400, 'Yalnız JPG, PNG veya WEBP fotoğraf yüklenebilir.');
    if ($info[0] < 50 || $info[1] < 50 || $info[0] * $info[1] > 40000000) fail_msg(400, 'Fotoğraf ölçüsü uygun değil.');
    if (!function_exists('imagecreatetruecolor')) fail_msg(500, 'Sunucuda resim işleme (GD) kapalı. Hosting firmanızdan açtırın.');
    $tmp = (string)$f['tmp_name'];
    switch ($info[2]) {
        case IMAGETYPE_JPEG: $im = @imagecreatefromjpeg($tmp); if ($im) $im = fix_orientation($im, $tmp); break;
        case IMAGETYPE_PNG: $im = @imagecreatefrompng($tmp); break;
        default: $im = function_exists('imagecreatefromwebp') ? @imagecreatefromwebp($tmp) : false;
    }
    if (!$im) fail_msg(400, 'Fotoğraf okunamadı. Başka bir dosya deneyin.');
    // Yeniden çizilerek kaydedilir: dosyanın içinde gizli bir şey kalmaz
    $w = imagesx($im); $hgt = imagesy($im);
    $scale = min(1, $s['max'] / max($w, $hgt));
    $nw = max(1, (int)round($w * $scale)); $nh = max(1, (int)round($hgt * $scale));
    $dst = imagecreatetruecolor($nw, $nh);
    if ($s['fmt'] === 'png') {
        imagealphablending($dst, false); imagesavealpha($dst, true);
        imagefill($dst, 0, 0, imagecolorallocatealpha($dst, 0, 0, 0, 127));
    } else {
        imagefill($dst, 0, 0, imagecolorallocate($dst, 255, 255, 255));
        imagealphablending($dst, true);
    }
    imagecopyresampled($dst, $im, 0, 0, 0, 0, $nw, $nh, $w, $hgt);
    $dir = SITE_ROOT . '/' . $s['dir'];
    ensure_dir($dir, false);
    $target = $dir . '/' . $s['file'];
    $tmpOut = $target . '.tmp' . bin2hex(random_bytes(4));
    $okw = $s['fmt'] === 'png' ? imagepng($dst, $tmpOut, 8) : imagejpeg($dst, $tmpOut, 84);
    imagedestroy($im); imagedestroy($dst);
    if (!$okw || !rename($tmpOut, $target)) { @unlink($tmpOut); fail_msg(500, 'Fotoğraf kaydedilemedi (klasör izni).'); }
    @chmod($target, 0644);
}

try {
    $a = (string)($_GET['a'] ?? '');
    if ($a === 'inbox') {
        out(200, ['ok' => true, 'items' => jread(DATA_DIR . '/teklifler.php', [])]);
    }
    if ($a === 'inboxdel') {
        $id = (string)($_POST['id'] ?? '');
        if (!preg_match('/^[0-9a-f]{12}$/', $id)) fail_msg(400, 'Geçersiz kayıt.');
        $list = array_values(array_filter(jread(DATA_DIR . '/teklifler.php', []), function ($x) use ($id) { return ($x['id'] ?? '') !== $id; }));
        jwrite(DATA_DIR . '/teklifler.php', $list, true);
        out(200, ['ok' => true]);
    }
    if ($a === 'save') {
        $raw = file_get_contents('php://input');
        if (strlen((string)$raw) > 600000) fail_msg(400, 'İçerik çok büyük.');
        $in = json_decode((string)$raw, true);
        if (!is_array($in)) fail_msg(400, 'Geçersiz içerik.');
        $v = save_content(clean_content($in));
        out(200, ['ok' => true, 'v' => $v]);
    }
    if ($a === 'upload') {
        $s = slot();
        process_upload($s);
        $c = load_content(); $v = save_content($c);
        out(200, ['ok' => true, 'file' => $s['file'], 'url' => '../' . $s['dir'] . '/' . $s['file'] . '?v=' . $v, 'v' => $v]);
    }
    if ($a === 'delete') {
        $s = slot();
        $p = SITE_ROOT . '/' . $s['dir'] . '/' . $s['file'];
        if (is_file($p)) @unlink($p);
        $c = load_content(); $v = save_content($c);
        out(200, ['ok' => true, 'v' => $v]);
    }
    fail_msg(400, 'Geçersiz işlem.');
} catch (Throwable $e) {
    fail_msg(500, 'Sunucuda bir sorun oluştu, kayıt yapılamadı. (' . get_class($e) . ')');
}
