'use strict';
// EFA Hazır Giyim — yönetim paneli arayüzü
(function () {
  const $ = (s, r = document) => r.querySelector(s);
  const $$ = (s, r = document) => [...r.querySelectorAll(s)];
  const esc = s => String(s == null ? '' : s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

  // Şifre göster/gizle (giriş ekranı)
  $$('.eye').forEach(b => b.addEventListener('click', () => { const i = b.previousElementSibling; i.type = i.type === 'password' ? 'text' : 'password'; }));
  if (!document.body.classList.contains('v-panel')) return;

  const CSRF = $('meta[name=csrf]').content;
  const app = $('#app');
  let PAGE, DEF, CUR = {}, dirty = false;
  const ST = { t: {}, n: {}, c: {}, steps: {}, docs: {}, refs: [] };
  const D = { t: {}, n: {}, c: {}, steps: {}, docs: {}, refs: [] };   // varsayılanlar

  async function api(a, body, isForm) {
    const opt = { method: 'POST', credentials: 'same-origin', headers: { 'X-CSRF': CSRF } };
    if (isForm) opt.body = body; else { opt.headers['Content-Type'] = 'application/json'; opt.body = JSON.stringify(body); }
    const r = await fetch('api.php?a=' + a, opt);
    let d = null; try { d = await r.json(); } catch (e) { /* boş */ }
    if (!d) throw new Error('Sunucudan yanıt alınamadı. İnternet bağlantınızı kontrol edin.');
    if (!r.ok || !d.ok) { if (r.status === 401) setTimeout(() => location.reload(), 2500); throw new Error(d.error || 'İşlem yapılamadı.'); }
    return d;
  }
  let toastT;
  function toast(m, bad) { const t = $('#toast'); t.textContent = m; t.className = 'toast show' + (bad ? ' bad' : ''); clearTimeout(toastT); toastT = setTimeout(() => { t.className = 'toast'; }, bad ? 6000 : 3500); }
  function setDirty(v) {
    dirty = v; $('#saveBtn').disabled = !v;
    $('#saveMsg').textContent = v ? 'Kaydedilmemiş değişiklikler var' : 'Tüm değişiklikler kayıtlı';
    $('#savebar').classList.toggle('on', v);
  }
  window.addEventListener('beforeunload', e => { if (dirty) { e.preventDefault(); e.returnValue = ''; } });

  // Sayfadaki HTML'i panelde düzenlenecek düz yazıya çevirir (**kalın**, satır sonu)
  function inl(el) {
    if (!el) return '';
    const c = el.cloneNode(true);
    c.querySelectorAll('br').forEach(b => b.replaceWith('\n'));
    c.querySelectorAll('b,strong').forEach(b => b.replaceWith('**' + b.textContent + '**'));
    return c.textContent.replace(/[ \t]+\n/g, '\n').trim();
  }
  function htmlToLite(html) {
    const d = document.createElement('div'); d.innerHTML = html; const out = [];
    d.childNodes.forEach(n => {
      if (n.nodeType !== 1) { const t = n.textContent.trim(); if (t) out.push(t); return; }
      if (n.tagName === 'H4') out.push('## ' + inl(n));
      else if (n.tagName === 'UL' || n.tagName === 'OL') out.push([...n.children].map(li => '- ' + inl(li).replace(/\n/g, ' ')).join('\n'));
      else out.push(inl(n));
    });
    return out.join('\n\n');
  }
  const rowsFor = s => Math.min(10, Math.max(1, Math.ceil(String(s).length / 60) + (String(s).split('\n').length - 1)));

  // ---------- Yükleme ----------
  Promise.all([
    fetch('../index.html', { cache: 'no-store' }).then(r => r.text()),
    fetch('../data/defaults.json', { cache: 'no-store' }).then(r => r.json()),
    fetch('../data/content.json', { cache: 'no-store' }).then(r => (r.ok ? r.json() : {})).catch(() => ({}))
  ]).then(([html, def, cur]) => {
    PAGE = new DOMParser().parseFromString(html, 'text/html');
    DEF = def; CUR = (cur && typeof cur === 'object' && !Array.isArray(cur)) ? cur : {};
    build();
  }).catch(e => { app.className = 'err'; app.textContent = 'Panel yüklenemedi: ' + e.message; });

  const GROUPS = [['hdr', 'Üst menü'], ['top', 'Açılış bölümü'], ['stats', 'Rakam kartları'], ['about', 'Hakkımızda'], ['process', '8 Adım kartları'],
    ['services', 'Hizmetlerimiz'], ['products', 'Ürünler'], ['capacity', 'Kapasite & Termin'], ['refs', 'Referanslar'], ['why', 'Neden Biz'],
    ['quote', 'Teklif formu'], ['contact', 'Alt bilgi (en alt)'], ['ck', 'Çerez bildirimi']];

  function build() {
    app.className = ''; app.innerHTML = '';
    // ---- Yazılar
    const seen = new Set(); const groups = [];
    GROUPS.forEach(([id, label]) => {
      const root = PAGE.getElementById(id); if (!root) return;
      const items = [];
      $$('[data-k][data-tr]', root).forEach(el => {
        const k = el.dataset.k; if (seen.has(k)) return; seen.add(k);
        const enEl = PAGE.querySelector(`[data-en][data-k="${k}"]`);
        D.t[k] = { tr: inl(el), en: inl(enEl) };
        const o = (CUR.t || {})[k] || {};
        ST.t[k] = { tr: o.tr || D.t[k].tr, en: o.en || D.t[k].en };
        items.push(k);
      });
      if (items.length) groups.push({ label, items });
    });
    let h = `<section class="pane" id="tab-texts"><h2>Yazılar</h2><p class="lead">Sitedeki tüm başlık ve yazılar burada. Solda Türkçe, sağda İngilizce. <b>**kalın**</b> yazmak için iki yıldız arasına alın.</p>
      <input class="search" id="tSearch" placeholder="🔎 Yazı ara (ör. kapasite, Sultangazi)…">`;
    groups.forEach((g, gi) => {
      h += `<details class="grp"${gi === 0 ? ' open' : ''}><summary>${esc(g.label)} <span class="cnt">${g.items.length}</span></summary><div class="grp-b">`;
      g.items.forEach(k => {
        const v = ST.t[k], d = D.t[k];
        h += `<div class="fld${(v.tr !== d.tr || v.en !== d.en) ? ' chg' : ''}" data-k="${esc(k)}"><div class="row2">
          <label><span class="lg">TR</span><textarea data-l="tr" rows="${rowsFor(v.tr)}">${esc(v.tr)}</textarea></label>
          <label><span class="lg">EN</span><textarea data-l="en" rows="${rowsFor(v.en)}">${esc(v.en)}</textarea></label></div>
          <button type="button" class="reset" title="İlk hâline döndür">↺ İlk hâli</button></div>`;
      });
      h += `</div></details>`;
    });
    h += `</section>`;

    // ---- Rakamlar
    const numRows = [];
    $$('.stat', PAGE).forEach(s => { const c = $('[data-n]', s); numRows.push(['Rakam kartları', inl($('span[data-tr]', s)), c.dataset.n, c.dataset.val]); });
    $$('.bar-row', PAGE).forEach(r => { const c = $('[data-n]', r); numRows.push(['Ürün bazında aylık kapasite (adet)', inl($('b span[data-tr]', r)), c.dataset.n, c.textContent.trim()]); });
    $$('.lt', PAGE).forEach(r => { const c = $('[data-n]', r); numRows.push(['Üretim süreleri (hafta)', inl($('.lt-t > span span[data-tr]', r)), c.dataset.n, c.textContent.trim()]); });
    $$('.card', PAGE).forEach(r => { const c = $('[data-n]', r); numRows.push(['Ürün kartlarındaki aylık kapasite (adet)', inl($('h3 span[data-tr]', r)), c.dataset.n, c.textContent.trim()]); });
    numRows.forEach(r => { D.n[r[2]] = r[3]; ST.n[r[2]] = (CUR.n || {})[r[2]] || r[3]; });
    h += `<section class="pane" id="tab-nums" hidden><h2>Rakamlar</h2><p class="lead">Sayılar sitede animasyonla gösterilir; kapasite ve termin çubukları yeni rakamlara göre kendiliğinden ayarlanır. Aralıkları <b>15.000 – 20.000</b> ya da <b>8–10</b> biçiminde yazın.</p>`;
    let lastG = '';
    numRows.forEach(r => {
      if (r[0] !== lastG) { if (lastG) h += `</div>`; h += `<h3 class="sub">${esc(r[0])}</h3><div class="card grid2">`; lastG = r[0]; }
      h += `<label class="num${ST.n[r[2]] !== D.n[r[2]] ? ' chg' : ''}">${esc(r[1])}<input data-n="${esc(r[2])}" value="${esc(ST.n[r[2]])}" maxlength="40"></label>`;
    });
    h += `</div><p class="hint">Kapasite başlığındaki "Aylık 25.000 – 30.000 adet" yazısını <b>Yazılar → Kapasite & Termin</b> bölümünden değiştirebilirsiniz.</p></section>`;

    // ---- 8 adım
    h += `<section class="pane" id="tab-steps" hidden><h2>8 Adım</h2><p class="lead">Sitedeki "Tek çatı altında 8 adım" kartlarına tıklanınca açılan pencerelerin yazıları ve fotoğrafları. Fotoğraflar yüklenir yüklenmez sitede görünür; yazılar için <b>Kaydet</b>e basın.</p>`;
    DEF.steps.forEach((s, i) => {
      D.steps[s.k] = {}; ST.steps[s.k] = {};
      ['tr', 'en'].forEach(l => {
        const d = { t: s[l].t, lead: s[l].lead, p: s[l].p.join('\n\n'), b: s[l].b.join('\n') };
        const o = ((CUR.steps || {})[s.k] || {})[l] || {};
        D.steps[s.k][l] = d;
        ST.steps[s.k][l] = { t: o.t || d.t, lead: o.lead || d.lead, p: o.p ? o.p.join('\n\n') : d.p, b: o.b ? o.b.join('\n') : d.b };
      });
      const sv = ST.steps[s.k];
      const col = l => `<div class="col"><span class="lg">${l.toUpperCase()}</span>
        <label>Başlık<input data-s="${s.k}" data-l="${l}" data-f="t" value="${esc(sv[l].t)}" maxlength="80"></label>
        <label>Kısa açıklama<input data-s="${s.k}" data-l="${l}" data-f="lead" value="${esc(sv[l].lead)}" maxlength="300"></label>
        <label>Metin <small>(paragrafları boş satırla ayırın)</small><textarea data-s="${s.k}" data-l="${l}" data-f="p" rows="7">${esc(sv[l].p)}</textarea></label>
        <label>Öne çıkanlar <small>(her satıra bir madde, en az 3)</small><textarea data-s="${s.k}" data-l="${l}" data-f="b" rows="4">${esc(sv[l].b)}</textarea></label></div>`;
      h += `<details class="grp step"${i === 0 ? ' open' : ''}><summary><span class="no">${String(i + 1).padStart(2, '0')}</span> ${esc(s.tr.t)}</summary><div class="grp-b">
        <div class="row2">${col('tr')}${col('en')}</div>
        <h4>Fotoğraflar <small>(yatay fotoğraf önerilir)</small></h4><div class="slots">${[1, 2, 3].map(n => slotHtml('step', s.k, n, `assets/img/bolumler/${s.k}-${n}.jpg`)).join('')}</div>
      </div></details>`;
    });
    h += `</section>`;

    // ---- Ürün fotoğrafları
    h += `<section class="pane" id="tab-prods" hidden><h2>Ürün Fotoğrafları</h2><p class="lead">Ürün kartlarının fotoğrafları. Kare ya da dikey fotoğraf en iyi görünür. Yüklediğiniz fotoğraf sitede hemen görünür.</p><div class="slots prods">`;
    DEF.products.forEach(p => { h += `<div class="pwrap"><b>${esc(p.tr)}</b>${slotHtml('product', p.k, 0, `assets/img/urunler/${p.k}.jpg`)}</div>`; });
    h += `</div></section>`;

    // ---- Referanslar
    D.refs = DEF.refs.map(r => ({ name: r.name, img: r.img }));
    ST.refs = (Array.isArray(CUR.refs) && CUR.refs.length ? CUR.refs : D.refs).map(r => ({ name: r.name, img: r.img || '' }));
    h += `<section class="pane" id="tab-refs" hidden><h2>Referanslar</h2><p class="lead">Kayan marka logoları. Sırayı oklarla değiştirin, yeni marka ekleyin, logo yükleyin. Bitince <b>Kaydet</b>e basın. Logo için şeffaf arka planlı PNG en iyisidir.</p>
      <div class="card"><div id="refList" class="refs"></div>
      <div class="addref"><input id="newRef" placeholder="Yeni marka adı (ör. Zara)" maxlength="60"><button type="button" class="btn sm" id="addRef">+ Marka ekle</button></div></div></section>`;

    // ---- İletişim
    const ph = $('[data-c="phone"]', PAGE), em = $('[data-c="email"]', PAGE), wa = $('[data-c="wa"]', PAGE), ad = $('[data-c="addr"]', PAGE);
    D.c = { phone: ph ? ph.textContent.trim() : '', email: em ? em.textContent.trim() : '', wa: wa ? (wa.getAttribute('href') || '').replace(/\D/g, '') : '', addr: inl(ad) };
    ST.c = Object.assign({}, D.c, CUR.c || {});
    h += `<section class="pane" id="tab-contact" hidden><h2>İletişim</h2><p class="lead">Sitenin her yerindeki telefon, e-posta, WhatsApp, adres ve harita bu bilgilerden güncellenir. Teklif formu da bu e-postaya gelir.</p>
      <div class="card grid2">
        <label>Telefon<input data-c="phone" value="${esc(ST.c.phone)}" maxlength="40" placeholder="+90 5xx xxx xx xx"></label>
        <label>E-posta<input data-c="email" type="email" value="${esc(ST.c.email)}" maxlength="120"></label>
        <label>WhatsApp numarası <small>(ülke koduyla, ör. 905389583797)</small><input data-c="wa" value="${esc(ST.c.wa)}" maxlength="20" inputmode="numeric"></label>
        <label class="wide">Fabrika adresi <small>(harita bu adresi gösterir)</small><textarea data-c="addr" rows="3" maxlength="300">${esc(ST.c.addr)}</textarea></label>
      </div></section>`;

    // ---- Yasal metinler
    const DN = { about: 'Hakkımızda (pencere)', privacy: 'Gizlilik Politikası (KVKK)', cookies: 'Çerez Politikası' };
    h += `<section class="pane" id="tab-docs" hidden><h2>Yasal Metinler</h2><p class="lead">En alttaki bağlantılardan açılan metinler.</p>
      <div class="help"><b>Yazım kuralları:</b> <code>## Başlık</code> ara başlık · <code>- madde</code> liste · boş satır = yeni paragraf · <code>**kalın**</code></div>`;
    Object.keys(DEF.docs).forEach(k => {
      D.docs[k] = {}; ST.docs[k] = {};
      ['tr', 'en'].forEach(l => { const d = { t: DEF.docs[k][l].t, h: htmlToLite(DEF.docs[k][l].h) }; const o = ((CUR.docs || {})[k] || {})[l] || {};
        D.docs[k][l] = d; ST.docs[k][l] = { t: o.t || d.t, h: o.h || d.h }; });
      const col = l => `<div class="col"><span class="lg">${l.toUpperCase()}</span><label>Başlık<input data-d="${k}" data-l="${l}" data-f="t" value="${esc(ST.docs[k][l].t)}" maxlength="120"></label>
        <label>Metin<textarea data-d="${k}" data-l="${l}" data-f="h" rows="16">${esc(ST.docs[k][l].h)}</textarea></label></div>`;
      h += `<details class="grp"><summary>${esc(DN[k] || k)}</summary><div class="grp-b"><div class="row2">${col('tr')}${col('en')}</div></div></details>`;
    });
    h += `</section>`;

    h += `<section class="pane" id="tab-inbox" hidden><h2>Gelen Teklifler</h2><p class="lead">Sitedeki teklif formundan gelen talepler. Her talep ayrıca e-postanıza gönderilir; e-posta istenmeyen kutusuna düşse bile burada kaybolmaz.</p><div id="inboxList" class="inbox"><div class="loading">Yükleniyor…</div></div></section>`;
    app.innerHTML = h;
    const pw = $('#tab-pw'); app.appendChild(pw);
    renderRefs();
    wire();
    $$('.slot').forEach(loadSlot);
    setDirty(false);
  }

  // ---------- Fotoğraf yuvaları ----------
  function slotHtml(type, key, n, path) {
    return `<div class="slot" data-type="${type}" data-key="${key}" data-n="${n}" data-path="${path}">
      <div class="pv"><img alt=""><span class="none">Fotoğraf yok<br><small>Sitede hazır görsel ya da tasarım kartı görünür</small></span></div>
      <div class="sb"><label class="btn sm">Fotoğraf Yükle<input type="file" accept="image/jpeg,image/png,image/webp" hidden></label><button type="button" class="btn ghost sm del">Kaldır</button></div>
      <div class="st"></div></div>`;
  }
  function loadSlot(sl, v) {
    const img = $('img', sl);
    img.onload = () => { sl.classList.add('has'); };
    img.onerror = () => { sl.classList.remove('has'); img.removeAttribute('src'); };
    img.src = '../' + sl.dataset.path + '?v=' + (v || CUR.v || Date.now());
  }
  function slotForm(sl, extra) {
    const fd = new FormData(); fd.append('type', sl.dataset.type); fd.append('key', sl.dataset.key); fd.append('n', sl.dataset.n);
    Object.keys(extra || {}).forEach(k => fd.append(k, extra[k])); return fd;
  }
  async function uploadSlot(sl, file, extra) {
    const st = $('.st', sl);
    if (!file) return null;
    if (!/^image\/(jpeg|png|webp)$/.test(file.type)) { toast('Yalnız JPG, PNG veya WEBP fotoğraf yükleyebilirsiniz.', true); return null; }
    if (file.size > 10 * 1024 * 1024) { toast('Fotoğraf 10 MB\'tan büyük. Daha küçük bir fotoğraf seçin.', true); return null; }
    const fd = slotForm(sl, extra); fd.append('f', file);
    sl.classList.add('busy'); st.textContent = 'Yükleniyor…';
    try { const d = await api('upload', fd, true); CUR.v = d.v; st.textContent = ''; return d; }
    catch (e) { st.textContent = ''; toast(e.message, true); return null; }
    finally { sl.classList.remove('busy'); }
  }

  // ---------- Referans listesi ----------
  function renderRefs() {
    const box = $('#refList');
    box.innerHTML = ST.refs.map((r, i) => `<div class="ref" data-i="${i}">
      <div class="lg-pv">${r.img ? `<img src="../assets/img/referanslar/${esc(r.img)}?v=${esc(CUR.v || '1')}" alt="">` : `<span>${esc(r.name)}</span>`}</div>
      <input class="rn" value="${esc(r.name)}" maxlength="60" aria-label="Marka adı">
      <label class="btn ghost sm">Logo<input type="file" accept="image/png,image/jpeg,image/webp" hidden class="rf"></label>
      <button type="button" class="ic up" title="Yukarı" ${i === 0 ? 'disabled' : ''}>↑</button>
      <button type="button" class="ic dn" title="Aşağı" ${i === ST.refs.length - 1 ? 'disabled' : ''}>↓</button>
      <button type="button" class="ic rm" title="Kaldır">✕</button></div>`).join('');
    $$('.ref img', box).forEach(im => { im.onerror = () => { im.replaceWith(Object.assign(document.createElement('span'), { textContent: im.closest('.ref').querySelector('.rn').value })); }; });
  }

  // ---------- Olaylar ----------
  function wire() {
    $$('#tabs button').forEach(b => b.addEventListener('click', () => {
      if (b.dataset.tab === 'inbox') loadInbox();
      $$('#tabs button').forEach(x => x.classList.toggle('on', x === b));
      $$('.pane').forEach(p => { p.hidden = p.id !== 'tab-' + b.dataset.tab; });
      $('#main').scrollTop = 0; window.scrollTo(0, 0);
    }));
    // yazılar
    $('#tab-texts').addEventListener('input', e => {
      if (e.target.id === 'tSearch') {
        const q = e.target.value.trim().toLocaleLowerCase('tr');
        $$('#tab-texts .fld').forEach(f => { const t = $$('textarea', f).map(x => x.value).join(' ').toLocaleLowerCase('tr'); f.hidden = !!q && t.indexOf(q) < 0; });
        $$('#tab-texts details.grp').forEach(g => { if (q) g.open = $$('.fld:not([hidden])', g).length > 0; });
        return;
      }
      const f = e.target.closest('.fld'); if (!f) return;
      const k = f.dataset.k; ST.t[k][e.target.dataset.l] = e.target.value;
      f.classList.toggle('chg', ST.t[k].tr !== D.t[k].tr || ST.t[k].en !== D.t[k].en); setDirty(true);
    });
    $('#tab-texts').addEventListener('click', e => {
      const b = e.target.closest('.reset'); if (!b) return;
      const f = b.closest('.fld'), k = f.dataset.k; ST.t[k] = { tr: D.t[k].tr, en: D.t[k].en };
      $('textarea[data-l=tr]', f).value = D.t[k].tr; $('textarea[data-l=en]', f).value = D.t[k].en; f.classList.remove('chg'); setDirty(true);
    });
    // rakamlar
    $('#tab-nums').addEventListener('input', e => { const n = e.target.dataset.n; if (!n) return; ST.n[n] = e.target.value; e.target.closest('label').classList.toggle('chg', e.target.value !== D.n[n]); setDirty(true); });
    // 8 adım yazıları
    $('#tab-steps').addEventListener('input', e => { const t = e.target; if (!t.dataset.s) return; ST.steps[t.dataset.s][t.dataset.l][t.dataset.f] = t.value; setDirty(true); });
    // iletişim
    $('#tab-contact').addEventListener('input', e => { const c = e.target.dataset.c; if (!c) return; ST.c[c] = e.target.value; setDirty(true); });
    // yasal metinler
    $('#tab-docs').addEventListener('input', e => { const t = e.target; if (!t.dataset.d) return; ST.docs[t.dataset.d][t.dataset.l][t.dataset.f] = t.value; setDirty(true); });
    // fotoğraf yükle / kaldır (8 adım + ürünler)
    document.addEventListener('change', async e => {
      const inp = e.target; if (inp.type !== 'file') return;
      const file = inp.files && inp.files[0]; inp.value = '';
      const sl = inp.closest('.slot');
      if (sl) { const d = await uploadSlot(sl, file); if (d) { loadSlot(sl, d.v); toast('Fotoğraf yüklendi. Sitede hemen görünür.'); } return; }
      const row = inp.closest('.ref');
      if (row) {
        const i = +row.dataset.i, name = ST.refs[i].name.trim();
        if (!name) { toast('Önce marka adını yazın.', true); return; }
        const fake = document.createElement('div'); fake.dataset.type = 'ref'; fake.dataset.key = ''; fake.dataset.n = '0'; fake.innerHTML = '<div class="st"></div>';
        row.classList.add('busy');
        const d = await uploadSlot(fake, file, { name });
        row.classList.remove('busy');
        if (d) { ST.refs[i].img = d.file; renderRefs(); setDirty(true); toast('Logo yüklendi. Listeyi kaydetmek için "Değişiklikleri Kaydet"e basın.'); }
      }
    });
    document.addEventListener('click', async e => {
      const del = e.target.closest('.slot .del'); if (!del) return;
      const sl = del.closest('.slot');
      if (!confirm('Bu fotoğraf silinsin mi?')) return;
      try { const d = await api('delete', slotForm(sl), true); CUR.v = d.v; loadSlot(sl, d.v); toast('Fotoğraf kaldırıldı.'); } catch (er) { toast(er.message, true); }
    });
    // referanslar
    $('#refList').addEventListener('input', e => { if (!e.target.classList.contains('rn')) return; ST.refs[+e.target.closest('.ref').dataset.i].name = e.target.value; setDirty(true); });
    $('#refList').addEventListener('click', e => {
      const b = e.target.closest('button'); if (!b) return; const i = +b.closest('.ref').dataset.i;
      if (b.classList.contains('up') && i > 0) [ST.refs[i - 1], ST.refs[i]] = [ST.refs[i], ST.refs[i - 1]];
      else if (b.classList.contains('dn') && i < ST.refs.length - 1) [ST.refs[i + 1], ST.refs[i]] = [ST.refs[i], ST.refs[i + 1]];
      else if (b.classList.contains('rm')) { if (!confirm(`"${ST.refs[i].name}" listeden kaldırılsın mı?`)) return; ST.refs.splice(i, 1); }
      else return;
      renderRefs(); setDirty(true);
    });
    const addRef = () => { const inp = $('#newRef'), v = inp.value.trim(); if (!v) { inp.focus(); return; } ST.refs.push({ name: v, img: '' }); inp.value = ''; renderRefs(); setDirty(true); toast('Marka eklendi. İsterseniz "Logo" ile logosunu yükleyin, sonra kaydedin.'); };
    $('#addRef').addEventListener('click', addRef);
    $('#newRef').addEventListener('keydown', e => { if (e.key === 'Enter') { e.preventDefault(); addRef(); } });
    $('#saveBtn').addEventListener('click', save);
    document.addEventListener('keydown', e => { if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 's') { e.preventDefault(); if (dirty) save(); } });
  }

  // ---------- Gelen teklifler ----------
  async function loadInbox() {
    const box = $('#inboxList');
    try {
      const d = await api('inbox', {});
      if (!d.items.length) { box.innerHTML = '<div class="card empty">Henüz teklif talebi yok.</div>'; return; }
      box.innerHTML = d.items.map(x => {
        const dt = new Date(x.tarih);
        const when = isNaN(dt) ? '' : dt.toLocaleString('tr-TR', { day: '2-digit', month: 'long', year: 'numeric', hour: '2-digit', minute: '2-digit' });
        const row = (k, v) => v ? `<div><span>${k}</span><b>${v}</b></div>` : '';
        return `<article class="card msg" data-id="${esc(x.id)}"><header><div><h3>${esc(x.firma)}</h3><small>${esc(when)} · ${esc(String(x.dil || '').toUpperCase())}</small></div>
          <button type="button" class="ic rm" title="Sil">✕</button></header>
          <div class="kv">${row('Ad Soyad', esc(x.ad))}${row('E-posta', `<a href="mailto:${esc(x.eposta)}">${esc(x.eposta)}</a>`)}${row('Telefon', x.tel ? `<a href="tel:${esc(String(x.tel).replace(/[^\d+]/g, ''))}">${esc(x.tel)}</a>` : '')}${row('Ürün grubu', esc(x.grup))}${row('Tahmini adet', esc(x.adet))}</div>
          ${x.mesaj ? `<p class="txt">${esc(x.mesaj).replace(/\n/g, '<br>')}</p>` : ''}
          <a class="btn sm" href="mailto:${esc(x.eposta)}?subject=${encodeURIComponent('EFA Hazır Giyim — teklif talebiniz')}">Yanıtla</a></article>`;
      }).join('');
    } catch (e) { box.innerHTML = `<div class="card empty">${esc(e.message)}</div>`; }
  }
  document.addEventListener('click', async e => {
    const b = e.target.closest('.msg .rm'); if (!b) return;
    if (!confirm('Bu teklif talebi silinsin mi?')) return;
    const fd = new FormData(); fd.append('id', b.closest('.msg').dataset.id);
    try { await api('inboxdel', fd, true); b.closest('.msg').remove(); toast('Talep silindi.'); if (!$('.msg')) loadInbox(); } catch (er) { toast(er.message, true); }
  });

  // ---------- Kaydet ----------
  function payload() {
    const o = { t: {}, n: {}, c: {}, steps: {}, docs: {} };
    Object.keys(ST.t).forEach(k => { const v = ST.t[k], d = D.t[k]; if (v.tr.trim() !== d.tr || v.en.trim() !== d.en) o.t[k] = { tr: v.tr.trim() || d.tr, en: v.en.trim() || d.en }; });
    Object.keys(ST.n).forEach(k => { if (ST.n[k].trim() && ST.n[k].trim() !== D.n[k]) o.n[k] = ST.n[k].trim(); });
    Object.keys(ST.c).forEach(k => { if (String(ST.c[k]).trim() !== D.c[k]) o.c[k] = String(ST.c[k]).trim(); });
    Object.keys(ST.steps).forEach(k => ['tr', 'en'].forEach(l => {
      const v = ST.steps[k][l], d = D.steps[k][l], e = {};
      if (v.t.trim() && v.t.trim() !== d.t) e.t = v.t.trim();
      if (v.lead.trim() && v.lead.trim() !== d.lead) e.lead = v.lead.trim();
      if (v.p.trim() !== d.p) e.p = v.p.split(/\n\s*\n/).map(x => x.trim()).filter(Boolean);
      if (v.b.trim() !== d.b) e.b = v.b.split('\n').map(x => x.trim()).filter(Boolean);
      if (Object.keys(e).length) { o.steps[k] = o.steps[k] || {}; o.steps[k][l] = e; }
    }));
    Object.keys(ST.docs).forEach(k => ['tr', 'en'].forEach(l => {
      const v = ST.docs[k][l], d = D.docs[k][l], e = {};
      if (v.t.trim() && v.t.trim() !== d.t) e.t = v.t.trim();
      if (v.h.trim() && v.h.trim() !== d.h) e.h = v.h.trim();
      if (Object.keys(e).length) { o.docs[k] = o.docs[k] || {}; o.docs[k][l] = e; }
    }));
    const refs = ST.refs.filter(r => r.name.trim()).map(r => (r.img ? { name: r.name.trim(), img: r.img } : { name: r.name.trim() }));
    if (JSON.stringify(refs) !== JSON.stringify(D.refs)) o.refs = refs;
    return o;
  }
  function check(o) {
    for (const k of Object.keys(o.steps)) for (const l of ['tr', 'en']) { const b = (o.steps[k][l] || {}).b; if (b && b.length < 3) return `"${ST.steps[k].tr.t}" adımında "Öne çıkanlar" en az 3 satır olmalı.`; }
    if (o.c.email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(o.c.email)) return 'E-posta adresi geçerli görünmüyor.';
    if (o.c.wa && !/^\d{10,15}$/.test(o.c.wa.replace(/\D/g, ''))) return 'WhatsApp numarası ülke koduyla 10–15 rakam olmalı (ör. 905389583797).';
    if (ST.refs.some(r => !r.name.trim())) return 'Referanslarda adı boş bir marka var.';
    return '';
  }
  async function save() {
    const o = payload(), bad = check(o);
    if (bad) { toast(bad, true); return; }
    const btn = $('#saveBtn'); btn.disabled = true; $('#saveMsg').textContent = 'Kaydediliyor…';
    try { const d = await api('save', o); CUR = Object.assign({}, o, { v: d.v }); setDirty(false); toast('Kaydedildi. Değişiklikler sitede hemen görünür.'); }
    catch (e) { setDirty(true); toast(e.message, true); }
  }
})();
