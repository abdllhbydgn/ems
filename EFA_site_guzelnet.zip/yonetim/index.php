<?php
// EFA Hazır Giyim — yönetim paneli: giriş, şifre değiştirme ve panel sayfası
declare(strict_types=1);
define('EFA', 1);
require __DIR__ . '/inc/lib.php';
sec_headers();
header("Content-Security-Policy: default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; font-src 'self' https://fonts.gstatic.com; img-src 'self' data: blob: https://unsplash.com https://images.unsplash.com; connect-src 'self'; frame-ancestors 'none'; base-uri 'self'; form-action 'self'; object-src 'none'");
start_session();
ensure_dir(DATA_DIR, true);

$msg = ''; $ok = '';
$act = (string)($_POST['act'] ?? '');
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!hash_equals((string)$_SESSION['csrf'], (string)($_POST['csrf'] ?? ''))) {
        $msg = 'Sayfanın süresi doldu. Lütfen tekrar deneyin.';
    } elseif ($act === 'login') {
        $left = lock_left();
        if ($left > 0) {
            $msg = 'Çok fazla hatalı deneme yapıldı. ' . (int)ceil($left / 60) . ' dakika sonra tekrar deneyin.';
        } elseif (check_login(trim((string)($_POST['u'] ?? '')), (string)($_POST['p'] ?? ''))) {
            session_regenerate_id(true);
            $_SESSION['uid'] = 1;
            $_SESSION['last'] = time();
            $_SESSION['ua'] = ua_hash();
            $_SESSION['csrf'] = bin2hex(random_bytes(32));
            clear_fail();
            header('Location: ./'); exit;
        } else {
            note_fail();
            usleep(700000);
            $msg = 'Kullanıcı adı veya şifre hatalı.';
        }
    } elseif ($act === 'setpw' && logged_in()) {
        $p0 = (string)($_POST['p0'] ?? ''); $p1 = (string)($_POST['p1'] ?? ''); $p2 = (string)($_POST['p2'] ?? '');
        $c = config();
        if (!password_verify($p0, (string)$c['hash'])) $msg = 'Mevcut şifre hatalı.';
        elseif ($p1 !== $p2) $msg = 'Yeni şifreler birbirinin aynısı değil.';
        elseif (!strong_pw($p1)) $msg = 'Yeni şifre en az 10 karakter olmalı, harf ve rakam içermeli.';
        elseif (password_verify($p1, (string)$c['hash'])) $msg = 'Yeni şifre eskisiyle aynı olamaz.';
        else {
            set_password($p1);
            session_regenerate_id(true);
            $_SESSION['csrf'] = bin2hex(random_bytes(32));
            header('Location: ./?ok=pw'); exit;
        }
    } elseif ($act === 'logout') {
        $_SESSION = [];
        session_destroy();
        header('Location: ./'); exit;
    }
}
if (($_GET['ok'] ?? '') === 'pw') $ok = 'Şifreniz değiştirildi.';

$view = 'login';
if (logged_in()) $view = config()['must'] ? 'setpw' : 'panel';
$csrf = (string)$_SESSION['csrf'];
?><!doctype html>
<html lang="tr">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="robots" content="noindex, nofollow">
<meta name="csrf" content="<?= h($csrf) ?>">
<title>Yönetim Paneli — EFA Hazır Giyim</title>
<link rel="icon" type="image/svg+xml" href="../assets/img/favicon.svg">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@700;800&family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="panel.css?v=20261008">
</head>
<body class="v-<?= h($view) ?>">
<?php if ($view === 'login'): ?>
<main class="auth">
  <form class="auth-card" method="post" autocomplete="on">
    <img src="../assets/img/logo.svg" alt="EFA Hazır Giyim" class="auth-logo">
    <h1>Yönetim Paneli</h1>
    <p class="sub">Sitenizi yönetmek için giriş yapın.</p>
    <?php if ($msg): ?><div class="alert err"><?= h($msg) ?></div><?php endif; ?>
    <input type="hidden" name="csrf" value="<?= h($csrf) ?>">
    <input type="hidden" name="act" value="login">
    <label>Kullanıcı adı<input name="u" required autocomplete="username" maxlength="40" autofocus></label>
    <label>Şifre<span class="pw"><input name="p" type="password" required autocomplete="current-password" maxlength="200"><button type="button" class="eye" aria-label="Şifreyi göster">👁</button></span></label>
    <button class="btn" type="submit">Giriş Yap</button>
    <a class="back" href="../">← Siteye dön</a>
  </form>
</main>
<?php elseif ($view === 'setpw'): ?>
<main class="auth">
  <form class="auth-card" method="post" autocomplete="off">
    <img src="../assets/img/logo.svg" alt="EFA Hazır Giyim" class="auth-logo">
    <h1>Yeni şifre belirleyin</h1>
    <p class="sub">Güvenliğiniz için ilk girişte size verilen şifreyi değiştirmeniz gerekiyor.</p>
    <?php if ($msg): ?><div class="alert err"><?= h($msg) ?></div><?php endif; ?>
    <input type="hidden" name="csrf" value="<?= h($csrf) ?>">
    <input type="hidden" name="act" value="setpw">
    <label>Size verilen şifre<input name="p0" type="password" required autocomplete="current-password"></label>
    <label>Yeni şifre<input name="p1" type="password" required minlength="10" autocomplete="new-password"></label>
    <label>Yeni şifre (tekrar)<input name="p2" type="password" required minlength="10" autocomplete="new-password"></label>
    <p class="hint">En az 10 karakter; harf ve rakam içersin.</p>
    <button class="btn" type="submit">Şifreyi Kaydet</button>
  </form>
  <form method="post" class="auth-out"><input type="hidden" name="csrf" value="<?= h($csrf) ?>"><input type="hidden" name="act" value="logout"><button type="submit">Çıkış</button></form>
</main>
<?php else: ?>
<header class="top">
  <a href="../" target="_blank" rel="noopener" class="brand"><img src="../assets/img/logo-beyaz.svg" alt="EFA Hazır Giyim"></a>
  <span class="ttl">Yönetim Paneli</span>
  <a class="tbtn" href="../" target="_blank" rel="noopener">Siteyi Gör ↗</a>
  <form method="post"><input type="hidden" name="csrf" value="<?= h($csrf) ?>"><input type="hidden" name="act" value="logout"><button class="tbtn out" type="submit">Çıkış</button></form>
</header>
<div class="shell">
  <nav class="tabs" id="tabs">
    <button data-tab="texts" class="on">✏️ Yazılar</button>
    <button data-tab="inbox">📥 Gelen Teklifler</button>
    <button data-tab="nums">🔢 Rakamlar</button>
    <button data-tab="steps">🧵 8 Adım</button>
    <button data-tab="prods">👗 Ürün Fotoğrafları</button>
    <button data-tab="refs">🏷️ Referanslar</button>
    <button data-tab="contact">📞 İletişim</button>
    <button data-tab="docs">📄 Yasal Metinler</button>
    <button data-tab="pw">🔒 Şifre</button>
  </nav>
  <main class="main" id="main">
    <?php if ($ok): ?><div class="alert ok"><?= h($ok) ?></div><?php endif; ?>
    <?php if ($msg): ?><div class="alert err"><?= h($msg) ?></div><?php endif; ?>
    <div id="app" class="loading">Yükleniyor…</div>
    <section id="tab-pw" class="pane" hidden>
      <h2>Şifre değiştir</h2>
      <form method="post" class="card pwform" autocomplete="off">
        <input type="hidden" name="csrf" value="<?= h($csrf) ?>">
        <input type="hidden" name="act" value="setpw">
        <label>Mevcut şifre<input name="p0" type="password" required autocomplete="current-password"></label>
        <label>Yeni şifre<input name="p1" type="password" required minlength="10" autocomplete="new-password"></label>
        <label>Yeni şifre (tekrar)<input name="p2" type="password" required minlength="10" autocomplete="new-password"></label>
        <p class="hint">En az 10 karakter; harf ve rakam içersin.</p>
        <button class="btn" type="submit">Şifreyi Değiştir</button>
      </form>
    </section>
  </main>
</div>
<div class="savebar" id="savebar"><span id="saveMsg">Değişiklik yok</span><button class="btn" id="saveBtn" disabled>Değişiklikleri Kaydet</button></div>
<div class="toast" id="toast" role="status" aria-live="polite"></div>
<?php endif; ?>
<script src="panel.js?v=20261008" defer></script>
</body>
</html>
