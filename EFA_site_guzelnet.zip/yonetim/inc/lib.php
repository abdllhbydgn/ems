<?php
// EFA Hazır Giyim — yönetim paneli ortak işlevleri (doğrudan açılamaz)
declare(strict_types=1);
if (!defined('EFA')) { http_response_code(403); exit; }
date_default_timezone_set('Europe/Istanbul');

const ADMIN_USER   = 'admin';
// İlk şifrenin özeti; ilk girişte şifre değiştirilir ve yeni özet _data/config.php'ye yazılır.
const INITIAL_HASH = '$2y$10$HRb4BJuxRPRjsrW7Qp0.Uu81oWXdZg0fSL20fvOmtZlFo3iqGOtiG';
const IDLE_SECONDS = 1800;   // 30 dk işlem yapılmazsa oturum kapanır
const MAX_TRY      = 5;      // 5 hatalı denemede
const LOCK_SECONDS = 900;    // 15 dk kilit

define('PANEL_DIR', dirname(__DIR__));
define('SITE_ROOT', dirname(__DIR__, 2));
define('DATA_DIR', PANEL_DIR . '/_data');
define('CONTENT_FILE', SITE_ROOT . '/data/content.json');

const STEP_KEYS = ['tasarim', 'modelhane', 'kumas', 'kesim', 'dikim', 'utu', 'kalite', 'paket'];
const PROD_KEYS = ['bluz', 'gomlek', 'bustiyer', 'etek', 'pantolon', 'sort', 'elbise', 'tulum'];
const DOC_KEYS  = ['about', 'privacy', 'cookies'];

function sec_headers(): void {
    header('X-Robots-Tag: noindex, nofollow');
    header('Cache-Control: no-store, max-age=0');
    header('X-Frame-Options: DENY');
    header('X-Content-Type-Options: nosniff');
    header('Referrer-Policy: same-origin');
}

function is_https(): bool {
    return (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off')
        || (($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '') === 'https')
        || ((string)($_SERVER['SERVER_PORT'] ?? '') === '443');
}

function ua_hash(): string { return hash('sha256', (string)($_SERVER['HTTP_USER_AGENT'] ?? '')); }

function start_session(): void {
    ini_set('session.use_strict_mode', '1');
    ini_set('session.use_only_cookies', '1');
    session_name('EFAADM');
    session_set_cookie_params(['lifetime' => 0, 'path' => '/', 'secure' => is_https(), 'httponly' => true, 'samesite' => 'Strict']);
    session_start();
    if (!empty($_SESSION['uid'])) {
        $stale = (time() - (int)($_SESSION['last'] ?? 0)) > IDLE_SECONDS;
        if ($stale || !hash_equals((string)($_SESSION['ua'] ?? ''), ua_hash())) {
            $_SESSION = [];
            session_regenerate_id(true);
        } else {
            $_SESSION['last'] = time();
        }
    }
    if (empty($_SESSION['csrf'])) $_SESSION['csrf'] = bin2hex(random_bytes(32));
}

function logged_in(): bool { return !empty($_SESSION['uid']); }

function ensure_dir(string $d, bool $deny): void {
    if (!is_dir($d)) @mkdir($d, 0755, true);
    if ($deny && !is_file($d . '/.htaccess')) {
        @file_put_contents($d . '/.htaccess', "<IfModule mod_authz_core.c>\n  Require all denied\n</IfModule>\n<IfModule !mod_authz_core.c>\n  Deny from all\n</IfModule>\n");
    }
}

// _data içindeki dosyalar .php uzantılı ve "exit" ile başlar: tarayıcıdan açılsa bile içerik görünmez.
function jread(string $f, array $def): array {
    if (!is_file($f)) return $def;
    $s = (string)file_get_contents($f);
    $s = preg_replace('/^<\?php exit; \?>\n/', '', $s);
    $d = json_decode((string)$s, true);
    return is_array($d) ? $d : $def;
}

function jwrite(string $f, array $d, bool $guard): void {
    $s = json_encode($d, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | ($guard ? JSON_PRETTY_PRINT : 0));
    if ($s === false) throw new RuntimeException('json');
    if ($guard) $s = "<?php exit; ?>\n" . $s;
    $tmp = $f . '.tmp' . bin2hex(random_bytes(4));
    if (file_put_contents($tmp, $s, LOCK_EX) === false) throw new RuntimeException('write');
    @chmod($tmp, $guard ? 0600 : 0644);
    if (!rename($tmp, $f)) { @unlink($tmp); throw new RuntimeException('rename'); }
}

function config(): array {
    $c = jread(DATA_DIR . '/config.php', []);
    if (empty($c['hash'])) $c = ['user' => ADMIN_USER, 'hash' => INITIAL_HASH, 'must' => true];
    return $c;
}

function client_ip(): string { return substr((string)($_SERVER['REMOTE_ADDR'] ?? '0'), 0, 45); }

function lock_left(): int {
    $a = jread(DATA_DIR . '/attempts.php', []);
    $r = $a[client_ip()] ?? null;
    if (is_array($r) && (int)$r['n'] >= MAX_TRY) {
        $left = LOCK_SECONDS - (time() - (int)$r['t']);
        if ($left > 0) return $left;
    }
    return 0;
}

function note_fail(): void {
    ensure_dir(DATA_DIR, true);
    $a = jread(DATA_DIR . '/attempts.php', []);
    foreach ($a as $ip => $r) if (time() - (int)($r['t'] ?? 0) > LOCK_SECONDS) unset($a[$ip]);
    $r = $a[client_ip()] ?? ['n' => 0, 't' => time()];
    $a[client_ip()] = ['n' => (int)$r['n'] + 1, 't' => time()];
    jwrite(DATA_DIR . '/attempts.php', $a, true);
}

function clear_fail(): void {
    $a = jread(DATA_DIR . '/attempts.php', []);
    if (isset($a[client_ip()])) { unset($a[client_ip()]); jwrite(DATA_DIR . '/attempts.php', $a, true); }
}

function check_login(string $u, string $p): bool {
    $c = config();
    $userOk = hash_equals((string)$c['user'], $u);
    $passOk = password_verify($p, (string)$c['hash']);
    return $userOk && $passOk;
}

function strong_pw(string $p): bool {
    return strlen($p) >= 10 && preg_match('/[A-Za-zÇĞİÖŞÜçğıöşü]/u', $p) && preg_match('/\d/', $p);
}

function set_password(string $p): void {
    ensure_dir(DATA_DIR, true);
    $c = config();
    $c['hash'] = password_hash($p, PASSWORD_DEFAULT);
    $c['must'] = false;
    $c['user'] = $c['user'] ?? ADMIN_USER;
    $c['changed'] = date('c');
    jwrite(DATA_DIR . '/config.php', $c, true);
}

function txt($v, int $max): string {
    if (!is_string($v)) return '';
    $v = str_replace(["\r\n", "\r"], "\n", $v);
    $v = trim(strip_tags($v));
    $v = preg_replace('/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]/u', '', $v) ?? '';
    return function_exists('mb_substr') ? mb_substr($v, 0, $max, 'UTF-8') : substr($v, 0, $max);
}

function slugify(string $s): string {
    $s = strtr($s, ['ç' => 'c', 'Ç' => 'c', 'ğ' => 'g', 'Ğ' => 'g', 'ı' => 'i', 'İ' => 'i', 'ö' => 'o', 'Ö' => 'o', 'ş' => 's', 'Ş' => 's', 'ü' => 'u', 'Ü' => 'u', '&' => ' ']);
    $s = strtolower($s);
    $s = trim((string)preg_replace('/[^a-z0-9]+/', '-', $s), '-');
    return substr($s !== '' ? $s : 'marka', 0, 60);
}

function h(string $s): string { return htmlspecialchars($s, ENT_QUOTES, 'UTF-8'); }
