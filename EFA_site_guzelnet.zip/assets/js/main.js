'use strict';
(function(){
  const html=document.documentElement;
  const words={tr:["modelhane","tasarım","kesim","dikim","kalite"],en:["pattern making","design","cutting","sewing","quality"]};
  function setLang(l){
    html.lang=l;
    document.querySelectorAll('.lang button').forEach(b=>b.classList.toggle('on',b.dataset.l===l));
    document.querySelectorAll('[data-ph-tr]').forEach(e=>e.placeholder=e.dataset['ph'+(l==='en'?'En':'Tr')]);
    document.querySelectorAll('[data-opt-tr]').forEach(e=>e.textContent=e.dataset['opt'+(l==='en'?'En':'Tr')]);
    try{localStorage.setItem('efaLang',l)}catch(e){}
  }
  document.querySelectorAll('.lang button').forEach(b=>b.onclick=()=>setLang(b.dataset.l));
  let saved='tr';try{saved=localStorage.getItem('efaLang')||(navigator.language||'tr').slice(0,2)}catch(e){}
  setLang(saved==='en'?'en':'tr');
  // rotating word
  let i=0;setInterval(()=>{i=(i+1)%5;['tr','en'].forEach(l=>{const el=document.getElementById(l==='tr'?'rotTr':'rotEn');if(!el)return;el.animate([{opacity:1,transform:'translateY(0)'},{opacity:0,transform:'translateY(-10px)'}],{duration:250}).onfinish=()=>{el.textContent=words[l][i];el.animate([{opacity:0,transform:'translateY(10px)'},{opacity:1,transform:'translateY(0)'}],{duration:300})}})},2600);
  // header
  const hdr=document.getElementById('hdr');const onS=()=>hdr.classList.toggle('solid',scrollY>40);addEventListener('scroll',onS,{passive:true});onS();
  // reveal + counters
  const io=new IntersectionObserver(es=>es.forEach(e=>{if(!e.isIntersecting)return;e.target.classList.add('in');e.target.querySelectorAll('.cnt').forEach(animCnt);io.unobserve(e.target)}),{threshold:.15});
  document.querySelectorAll('.reveal').forEach((el,k)=>{el.style.transitionDelay=(k%7)*80+'ms';io.observe(el)});
  // product tabs
  document.querySelectorAll('.prod-tabs button').forEach(b=>b.onclick=()=>{document.querySelectorAll('.prod-tabs button').forEach(x=>x.classList.toggle('on',x===b));document.querySelectorAll('.card').forEach(c=>c.classList.toggle('hide',b.dataset.g!=='all'&&c.dataset.g!==b.dataset.g))});
  document.querySelectorAll('.menu a').forEach(a=>a.onclick=()=>document.getElementById('menu').classList.remove('open'));
  document.getElementById('yr').textContent=new Date().getFullYear();
  // ===== Mobil menü =====
  const burger=document.getElementById('burger'),menu=document.getElementById('menu');
  burger.addEventListener('click',()=>{const o=menu.classList.toggle('open');burger.setAttribute('aria-expanded',String(o))});
  document.addEventListener('click',e=>{if(menu.classList.contains('open')&&!e.target.closest('#menu,#burger')){menu.classList.remove('open');burger.setAttribute('aria-expanded','false')}});
  // ===== Görseller: dosya bulunamazsa yedek göster (logo -> eski site -> marka adı; fotoğraf -> kutu/ikon) =====
  function imgFail(img){
    if(img.dataset.remote&&!img.dataset.tried){img.dataset.tried='1';const a0=img.closest('.gal a');if(a0)a0.href=img.dataset.remote;img.src=img.dataset.remote;return}
    if(img.closest('.logo-tile')){const b=document.createElement('b');b.lang='en';b.textContent=(img.dataset.name||img.alt).toUpperCase();img.replaceWith(b);return}
    const a=img.closest('.gal a');if(a){a.remove();return}
    img.remove();
  }
  function wireImgs(scope){scope.querySelectorAll('img').forEach(img=>{if(img.dataset.w)return;img.dataset.w='1';img.addEventListener('error',()=>imgFail(img));if(img.complete&&img.naturalWidth===0&&img.getAttribute('src'))imgFail(img)})}
  wireImgs(document);
  // ===== Teklif formu: e-posta uygulamasını hazır metinle açar (sunucuya veri gönderilmez) =====
  const qf=document.getElementById('qform'),fmsg=document.getElementById('fmsg'),qwa=document.getElementById('qwa');
  let QMAIL='ezgi.cubukcu@efahazirgiyim.com',QWA='905389583797';
  function qText(){const f=qf.elements,en=html.lang==='en',g=f.grup.selectedIndex>0?f.grup.options[f.grup.selectedIndex].textContent:'';
    const rows=[[en?'Name':'Ad Soyad',f.ad.value],[en?'Company':'Firma',f.firma.value],[en?'E-mail':'E-posta',f.eposta.value],[en?'Phone':'Telefon',f.tel.value],[en?'Product group':'Ürün grubu',g],[en?'Quantity':'Adet',f.adet.value],[en?'Details':'Detaylar',f.mesaj.value]];
    return rows.filter(r=>String(r[1]).trim()).map(r=>r[0]+': '+String(r[1]).trim()).join('\n')}
  // Form doğrudan sunucuya gönderilir (teklif.php); sunucu yoksa e-posta uygulaması açılır
  const qTs=Date.now();
  function qMailto(en){const subj=(en?'Quote request - ':'Teklif talebi - ')+qf.elements.firma.value.trim();
    location.href='mailto:'+QMAIL+'?subject='+encodeURIComponent(subj)+'&body='+encodeURIComponent(qText());
    fmsg.className='fmsg full ok';fmsg.textContent=en?'Your e-mail app has opened with the details — just press Send. If it did not open, use WhatsApp below.':'E-posta uygulamanız bilgilerle açıldı — yalnızca Gönder\'e basın. Açılmadıysa aşağıdan WhatsApp ile gönderin.'}
  qf.addEventListener('submit',async e=>{e.preventDefault();const en=html.lang==='en';
    if(!qf.checkValidity()){const bad=qf.querySelector(':invalid');fmsg.className='fmsg full err';fmsg.textContent=en?'Please fill in the required fields and confirm the privacy notice.':'Lütfen zorunlu alanları doldurun ve KVKK metnini onaylayın.';if(bad)bad.focus();return}
    const btn=qf.querySelector('button[type=submit]');if(btn.disabled)return;btn.disabled=true;
    fmsg.className='fmsg full';fmsg.textContent=en?'Sending…':'Gönderiliyor…';
    const fd=new FormData(qf);fd.append('ts',String(qTs));fd.append('lang',en?'en':'tr');
    if(qf.elements.grup.selectedIndex>0)fd.set('grup',qf.elements.grup.options[qf.elements.grup.selectedIndex].textContent);
    try{const r=await fetch('teklif.php',{method:'POST',body:fd,credentials:'same-origin'});let d=null;try{d=await r.json()}catch(x){}
      if(!d){qMailto(en);return}
      if(d.ok){qf.reset();fmsg.className='fmsg full ok';fmsg.textContent=en?'Thank you! Your request has reached us. We will get back to you within 24 hours.':'Teşekkürler! Talebiniz bize ulaştı. 24 saat içinde size dönüş yapacağız.';return}
      fmsg.className='fmsg full err';fmsg.textContent=(en?d.en:d.tr)||(en?'Could not send. Please try WhatsApp below.':'Gönderilemedi. Lütfen aşağıdan WhatsApp ile deneyin.');
    }catch(x){qMailto(en)}finally{btn.disabled=false}});
  qwa.addEventListener('click',()=>{const t=qText();qwa.href='https://wa.me/'+QWA+(t?'?text='+encodeURIComponent((html.lang==='en'?'Quote request\n':'Teklif talebi\n')+t):'')});
  // ===== Konum haritası: Harita / Uydu =====
  const mapIf=document.getElementById('mapIf');
  document.querySelectorAll('.map-tabs button').forEach(b=>b.addEventListener('click',()=>{
    document.querySelectorAll('.map-tabs button').forEach(x=>x.classList.toggle('on',x===b));
    mapIf.src='https://www.google.com/maps?q='+mapIf.dataset.q+'&z='+(b.dataset.map==='k'?'19':'17')+(b.dataset.map==='k'?'&t=k':'')+'&output=embed';
  }));
  // ===== Yönetim panelinden gelen içerik (data/content.json) =====
  let IMGV = '';
  function animCnt(c){
    const v = String(c.dataset.val || c.textContent).trim(); let m;
    const run = (from, to, set) => { const t0 = performance.now(); const tick = t => { const p = Math.min(1, (t - t0) / 1600); set(Math.round(from + (to - from) * (1 - Math.pow(1 - p, 3)))); if (p < 1) requestAnimationFrame(tick); }; requestAnimationFrame(tick); };
    if (/^\d+$/.test(v)) { const to = +v; run(to >= 1000 ? to - 40 : 0, to, x => { c.textContent = x; }); }
    else if ((m = v.match(/^(\d+)\s*[–-]\s*(\d+)$/))) { const a = m[1], to = +m[2]; run(Math.min(+a, to), to, x => { c.textContent = a + '–' + x; }); }
    else c.textContent = v;
  }
  const escH = s => String(s).replace(/[&<>"']/g, ch => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[ch]));
  const inlB = s => escH(s).replace(/\*\*(.+?)\*\*/g, '<b>$1</b>');
  const inlD = s => inlB(s).replace(/(^|[\s(])([\w.+-]+@[\w-]+\.[\w.]+)/g, '$1<a href="mailto:$2">$2</a>');
  // Basit yazım: "## Başlık", "- madde", boş satır = yeni paragraf, **kalın**
  function liteBlock(s){
    const out = []; let ul = null, para = [];
    const flush = () => { if (para.length) { out.push('<p>' + para.map(inlD).join('<br>') + '</p>'); para = []; } };
    String(s).replace(/\r/g, '').split('\n').forEach(line => {
      const t = line.trim();
      if (/^- /.test(t)) { flush(); (ul = ul || []).push('<li>' + inlD(t.slice(2)) + '</li>'); return; }
      if (ul) { out.push('<ul>' + ul.join('') + '</ul>'); ul = null; }
      if (/^## /.test(t)) { flush(); out.push('<h4>' + inlD(t.slice(3)) + '</h4>'); return; }
      if (!t) { flush(); return; }
      para.push(t);
    });
    if (ul) out.push('<ul>' + ul.join('') + '</ul>');
    flush(); return out.join('');
  }
  const nums = s => String(s).split(/[–-]/).map(x => parseInt(x.replace(/\D/g, ''), 10) || 0);
  function capBars(){
    const rows = [...document.querySelectorAll('.bar-row')];
    if (rows.length) {
      const vals = rows.map(r => nums(r.querySelector('[data-n^="cap"]').textContent));
      const mx = Math.max(...vals.map(v => v[v.length - 1])) || 1, scale = Math.ceil(mx / 5000) * 5000;
      rows.forEach((r, i) => { const v = vals[i];
        r.querySelector('i.mx').style.setProperty('--w', (v[v.length - 1] / scale * 100).toFixed(1) + '%');
        r.querySelector('i.mn').style.setProperty('--w', (v[0] / scale * 100).toFixed(1) + '%'); });
      const cm = document.getElementById('capMax'); if (cm) cm.textContent = scale.toLocaleString('tr-TR');
    }
    const lts = [...document.querySelectorAll('.lt')];
    if (lts.length) {
      const lv = lts.map(l => nums(l.querySelector('[data-n^="lt"]').textContent));
      const lm = Math.max(...lv.map(v => v[v.length - 1])) || 1;
      lts.forEach((l, i) => { const v = lv[i]; l.querySelector('.lt-bar i').style.setProperty('--w', (v[v.length - 1] / lm * 100).toFixed(1) + '%'); });
    }
  }
  function applyContent(d){
    if (!d || typeof d !== 'object') return;
    if (d.v) IMGV = '?v=' + encodeURIComponent(d.v);
    const T = d.t || {};
    document.querySelectorAll('[data-k]').forEach(el => { const o = T[el.dataset.k]; if (!o) return;
      const l = el.hasAttribute('data-en') ? 'en' : 'tr';
      if (typeof o[l] === 'string' && o[l].trim()) el.innerHTML = inlB(o[l].trim()).replace(/\n/g, '<br>'); });
    const N = d.n || {};
    document.querySelectorAll('[data-n]').forEach(el => { const v = N[el.dataset.n]; if (typeof v !== 'string' || !v.trim()) return;
      el.textContent = v.trim(); if (el.classList.contains('cnt')) el.dataset.val = v.trim(); });
    capBars();
    const C = d.c || {};
    if (C.phone) { const tel = C.phone.replace(/[^\d+]/g, ''); document.querySelectorAll('[data-c="phone"]').forEach(a => { a.textContent = C.phone; a.href = 'tel:' + tel; }); }
    if (C.email) { document.querySelectorAll('[data-c="email"]').forEach(a => { a.textContent = C.email; a.href = 'mailto:' + C.email; }); QMAIL = C.email; }
    if (C.wa) { const w = C.wa.replace(/\D/g, ''); document.querySelectorAll('[data-c="wa"]').forEach(a => { a.href = 'https://wa.me/' + w; }); QWA = w; }
    if (C.addr) {
      document.querySelectorAll('[data-c="addr"]').forEach(a => { a.innerHTML = escH(C.addr).replace(/\n/g, '<br>'); });
      const q = encodeURIComponent(C.addr.replace(/\s*\n\s*/g, ' '));
      document.querySelectorAll('[data-c="mapdir"]').forEach(a => { a.href = 'https://www.google.com/maps/dir/?api=1&destination=' + q; });
      document.querySelectorAll('[data-c="mapsearch"]').forEach(a => { a.href = 'https://www.google.com/maps/search/?api=1&query=' + q; });
      const mi = document.getElementById('mapIf');
      if (mi) { mi.dataset.q = q; const sat = document.querySelector('.map-tabs button.on[data-map="k"]'); mi.src = 'https://www.google.com/maps?q=' + q + '&z=' + (sat ? '19&t=k' : '17') + '&output=embed'; }
    }
    if (d.steps) STEPS.forEach(s => { const o = d.steps[s.k]; if (!o) return;
      ['tr', 'en'].forEach(l => { const x = o[l], t = s[l]; if (!x) return;
        if (x.t) t.t = x.t; if (x.lead) t.lead = x.lead;
        if (Array.isArray(x.p) && x.p.length) t.p = x.p;
        if (Array.isArray(x.b) && x.b.length >= 3) t.b = x.b; }); });
    if (d.docs) Object.keys(DOCS).forEach(k => { const o = d.docs[k]; if (!o) return;
      ['tr', 'en'].forEach(l => { const x = o[l]; if (!x) return; if (x.t) DOCS[k][l].t = x.t; if (x.h) DOCS[k][l].h = liteBlock(x.h); }); });
    if (Array.isArray(d.refs) && d.refs.length) {
      const w = document.querySelector('.mq-wrap');
      if (w) {
        const L = d.refs.filter(r => r && r.name), half = Math.ceil(L.length / 2);
        const tile = (r, h) => `<div class="logo-tile" title="${escH(r.name)}"${h ? ' aria-hidden="true"' : ''}>` +
          (r.img ? `<img src="assets/img/referanslar/${escH(r.img)}${IMGV}" alt="${h ? '' : escH(r.name)}" loading="lazy" data-name="${escH(r.name)}">` : `<b lang="en">${escH(r.name.toUpperCase())}</b>`) + '</div>';
        const trk = (l, rev) => `<div class="marquee"><div class="track${rev ? ' rev' : ''}">${l.map(r => tile(r)).join('')}${l.map(r => tile(r, 1)).join('')}</div></div>`;
        w.innerHTML = trk(L.slice(0, half)) + (L.length > 1 ? trk(L.slice(half), 1) : '');
        wireImgs(w);
      }
    }
    if (IMGV) document.querySelectorAll('img[src^="assets/img/urunler/"]').forEach(i => { if (!i.dataset.tried && i.getAttribute('src').indexOf('?') < 0) i.src = i.getAttribute('src') + IMGV; });
  }
  fetch('data/content.json', { cache: 'no-store' }).then(r => r.ok ? r.json() : null).then(applyContent).catch(() => {});
  // ===== Bölüm içerikleri / Section content =====
  // Fotoğraflar: assets/img/bolumler/ klasörüne "modelhane-1.jpg, modelhane-2.jpg, modelhane-3.jpg" gibi adlarla koyun.
  // Bulunmayan fotoğrafın yerinde "Fotoğraf eklenecek" kutusu görünür. / Missing photos show a placeholder.
  const PHOTO_COUNT = 3;
  // Yerel fotoğraf yoksa kullanılacak telifsiz görseller (Unsplash). Açılmayan görselin yerinde tasarım kartı kalır.
  const STOCK = {
    tasarim: ["y7-oNbPInNk", "ZqZ9YCqbkb4", "1lg6Gn0-o54"],
    modelhane: ["BlC9hgJrZ18", "aRmdAZcc-dI", "9aibwKL9ED0"],
    kumas: ["rEb9iHOF638"],
    kesim: ["LtIDJLDjZnI"],
    dikim: ["oE8gTCYUmYM", "eFAvYBCfmJY", "uEb_cV7RE0Q"],
    utu: ["fuBvATyVe64", "RDP03vDlsfw"],
    kalite: ["dnvt4WTR3SY", "Yn5QX9Bzw28", "9YvcbvcFQt4"],
    paket: []
  };
  const stockUrl = id => `https://unsplash.com/photos/${id}/download?force=true&w=1200`;
  const STEPS = [
    { k: "tasarim",
      tr: { t: "Tasarım", lead: "Markanızın koleksiyon hedeflerini güncel trendlerle buluşturuyoruz.",
        p: ["Tasarım ekibimiz sezon trendlerini, kumaş ve aksesuar seçeneklerini markanızın kimliğiyle birlikte değerlendirir. Koleksiyon fikrinden başlayarak her modeli üretilebilir ve maliyet açısından doğru bir ürüne dönüştürürüz.",
             "Teknik çizimler (tech pack), renk kartelaları ve ölçü önerileri hazırlayarak ürünün modelhaneye ve üretime en doğru şekilde geçmesini sağlarız."],
        b: ["Trend ve pazar analizi", "Teknik çizim ve tech pack", "Renk, kumaş ve aksesuar seçimi", "Koleksiyon geliştirme desteği"] },
      en: { t: "Design", lead: "We bring your collection goals together with current trends.",
        p: ["Our design team evaluates seasonal trends, fabric and trim options together with your brand identity. Starting from the collection idea, we turn every style into a product that is both manufacturable and cost-effective.",
            "By preparing technical drawings (tech packs), colour cards and size recommendations, we make sure each product moves smoothly into the pattern room and production."],
        b: ["Trend and market research", "Technical drawings and tech packs", "Colour, fabric and trim selection", "Collection development support"] } },
    { k: "modelhane",
      tr: { t: "Modelhane", lead: "Doğru kalıp, kusursuz duruşun başlangıcıdır.",
        p: ["Kalıp hazırlama, numune dikimi ve prova süreçlerini deneyimli modelistlerimizle yürütüyoruz. Bilgisayar destekli kalıp sistemleriyle beden serilerini çıkarır, her bedende aynı duruşu yakalarız.",
             "Proto, fit ve üretim öncesi (PPS) numuneleri hızla hazırlar; onaylanan numuneye göre ölçü tablosunu kesinleştirerek üretime hatasız başlarız."],
        b: ["Bilgisayarlı kalıp ve serileme", "Proto, fit ve PPS numuneleri", "Prova ve ölçü düzeltmeleri", "Hızlı numune teslimi"] },
      en: { t: "Pattern Room", lead: "The right pattern is where a perfect fit begins.",
        p: ["Pattern making, sample sewing and fittings are carried out by our experienced pattern makers. With computer-aided pattern systems we grade full size sets and keep the same fit in every size.",
            "We prepare proto, fit and pre-production (PPS) samples quickly and finalise the size spec from the approved sample, so production starts right first time."],
        b: ["Computerised pattern making and grading", "Proto, fit and PPS samples", "Fittings and measurement corrections", "Fast sample delivery"] } },
    { k: "kumas",
      tr: { t: "Kumaş", lead: "Kaliteli ürün, doğru kumaşla başlar.",
        p: ["Dokuma kumaş tedarikinde güvenilir üreticilerle çalışıyor; poplin, gabardin, twill, keten, denim, viskon gibi geniş bir yelpazede markanıza en uygun kumaşı buluyoruz.",
             "Gelen her kumaş partisini üretim öncesi kontrol ederiz. Çekmezlik, renk haslığı, en ve kusur kontrolleriyle kumaşın kesime hazır olduğundan emin oluruz."],
        b: ["Kumaş tedariki ve fiyat optimizasyonu", "Gelen kumaş kontrolü (4 puan sistemi)", "Çekmezlik ve yıkama testleri", "Sertifikalı kumaş seçenekleri"] },
      en: { t: "Fabric", lead: "A quality garment starts with the right fabric.",
        p: ["We work with reliable mills for woven fabrics and source the best fit for your brand from a wide range — poplin, gabardine, twill, linen, denim, viscose and more.",
            "Every incoming fabric lot is inspected before production. Shrinkage, colour fastness, width and defect checks make sure the fabric is ready for cutting."],
        b: ["Fabric sourcing and cost optimisation", "Incoming fabric inspection (4-point system)", "Shrinkage and wash tests", "Certified fabric options"] } },
    { k: "kesim",
      tr: { t: "Kesim", lead: "Hassas kesim, yüksek verim.",
        p: ["Bilgisayarlı pastal planlama ile kumaş verimini en üst seviyeye çıkarıyor, maliyeti düşürüyoruz. Pastal serimi ve kesim, kalıba birebir uygun ve hassas şekilde yapılır.",
             "Kesilen parçalar beden, renk ve parti bazında numaralanarak dikime gönderilir; böylece karışıklık ve renk farkı oluşmaz."],
        b: ["Bilgisayarlı pastal planı", "Yüksek kumaş verimi", "Hassas kesim ve numaralama", "Kesim sonrası parça kontrolü"] },
      en: { t: "Cutting", lead: "Precise cutting, high efficiency.",
        p: ["Computerised marker planning maximises fabric yield and lowers cost. Spreading and cutting are done precisely, exactly to the pattern.",
            "Cut pieces are numbered by size, colour and lot before going to sewing, so there is no mix-up or shade variation."],
        b: ["Computerised marker planning", "High fabric yield", "Precise cutting and bundle numbering", "Post-cutting piece inspection"] } },
    { k: "dikim",
      tr: { t: "Dikim", lead: "Uzman ellerde, seri ve özenli üretim.",
        p: ["Deneyimli operatörlerden oluşan dikim hatlarımızda bluzdan pantolona, elbiseden eteğe kadın dokuma ürünleri seri ve özenli şekilde üretiyoruz.",
             "Hat içi kalite kontrol noktalarıyla olası hatalar daha oluşurken yakalanır. Günlük üretim takibi sayesinde termin planına sadık kalırız."],
        b: ["Ürün grubuna özel dikim hatları", "Deneyimli operatörler", "Hat içi kalite kontrol", "Günlük üretim ve termin takibi"] },
      en: { t: "Sewing", lead: "Fast, careful production in expert hands.",
        p: ["On sewing lines staffed by experienced operators we produce women's woven garments — from blouses to trousers, dresses to skirts — quickly and with care.",
            "Inline quality checkpoints catch issues as they happen, and daily production tracking keeps us on schedule."],
        b: ["Lines dedicated to product groups", "Experienced operators", "Inline quality control", "Daily output and lead-time tracking"] } },
    { k: "utu",
      tr: { t: "Ütü", lead: "Ürün, son görünümüne burada kavuşur.",
        p: ["Ütü ve son işlem bölümümüzde buharlı ütü ve pres makineleriyle her ürüne formunu veriyoruz. İplik temizliği ve son görünüm kontrolleri bu aşamada yapılır.",
             "Amacımız, ürünün mağaza rafına ve son kullanıcıya ilk günkü görünümüyle ulaşmasıdır."],
        b: ["Buharlı ütü ve pres", "İplik temizliği", "Leke ve son görünüm kontrolü", "Ürüne özel form verme"] },
      en: { t: "Pressing", lead: "Where every garment gets its final look.",
        p: ["In our pressing and finishing department, steam irons and presses give each garment its shape. Thread trimming and final appearance checks are done at this stage.",
            "Our aim is for every product to reach the store and the end customer looking as good as on day one."],
        b: ["Steam ironing and pressing", "Thread trimming", "Stain and final appearance check", "Product-specific shaping"] } },
    { k: "kalite",
      tr: { t: "Kalite Kontrol", lead: "Kalite tesadüf değil, akıllı bir gayretin sonucudur.",
        p: ["Kalite kontrol ekibimiz kumaştan sevkiyata kadar her aşamada ara (inline) ve final kontroller yapar. Final kontroller uluslararası AQL standartlarına göre yürütülür.",
             "Ölçü, dikiş ve görünüm hataları kayıt altına alınır, nedenleri analiz edilir ve üretime geri bildirim verilerek sürekli iyileştirme sağlanır."],
        b: ["Ara ve final kontrol", "AQL standartlarında denetim", "Ölçü, dikiş ve görünüm kontrolü", "Raporlama ve sürekli iyileştirme"] },
      en: { t: "Quality Control", lead: "Quality is never an accident; it is the result of intelligent effort.",
        p: ["Our QC team performs inline and final inspections at every stage, from fabric to shipment. Final inspections follow international AQL standards.",
            "Measurement, stitching and appearance defects are recorded, root causes are analysed and fed back to production for continuous improvement."],
        b: ["Inline and final inspection", "AQL-based audits", "Measurement, stitching and appearance checks", "Reporting and continuous improvement"] } },
    { k: "paket",
      tr: { t: "Paketleme", lead: "Doğru paket, zamanında sevkiyat.",
        p: ["Ürünler müşteri talimatlarına göre etiketlenir, katlanır, poşetlenir ve kolilenir. Barkod, askılık ve aksesuar uygulamaları bu aşamada tamamlanır.",
             "Çeki listesi ve sevkiyat belgeleri hazırlanarak ürünler planlanan tarihte yola çıkar."],
        b: ["Etiket, barkod ve askılık", "Talimata uygun katlama ve poşetleme", "Koli ve çeki listesi", "Zamanında sevkiyat"] },
      en: { t: "Packing", lead: "Correct packing, on-time shipment.",
        p: ["Garments are labelled, folded, bagged and cartoned according to customer instructions. Barcodes, hangers and trims are applied at this stage.",
            "Packing lists and shipping documents are prepared so goods leave on the planned date."],
        b: ["Labels, barcodes and hangers", "Folding and bagging to instructions", "Cartons and packing lists", "On-time shipment"] } }
  ];
  const UPD = "08.10.2026";
  const MAIL = "ezgi.cubukcu@efahazirgiyim.com";
  const DOCS = {
    about: {
      tr: { t: "Hakkımızda", h: `<p class="lead">2014 yılında fason atölye olarak kurulan ve sonrasında edindiği tecrübe ile ihracatçı konumuna gelen EFA Hazır Giyim, bugün Planlama, Modelhane, Showroom, Kesim, Dikim, Ütü-Paket bölümleri ve iş ortakları ile faaliyet göstermektedir.</p>
        <p>EFA Hazır Giyim, dokuma ürün grubunda etek, elbise, bluz, gömlek, büstiyer, tulum, şort ve pantolon olmak üzere kadın hazır giyim ürünleri üretmektedir.</p>
        <p>İstanbul Sultangazi'de toplam 1200 m² kapalı alanda, 80'i aşkın çalışanı ile müşteri faydasına odaklanmayı temel prensip hâline getirmiş olan firmamız, işini her zaman motivasyon ve enerji ile yapmaktadır.</p>
        <h4>Üretim kapasitemiz</h4><p>Aylık toplam <strong>25.000 – 30.000 adet</strong>. Ürün bazında aylık kapasite:</p>
        <ul><li>Şort / Pantolon / Gömlek: 15.000 – 20.000 adet</li><li>Etek / Bluz: 18.000 – 25.000 adet</li><li>Büstiyer: 15.000 – 25.000 adet</li><li>Elbise: 15.000 – 20.000 adet</li><li>Tulum: 12.000 – 15.000 adet</li></ul>
        <h4>Üretim sürelerimiz</h4><ul><li>Yeni koleksiyonlar: 8–10 hafta</li><li>Temel modeller: 6–8 hafta</li><li>Tekrar (repeat) modeller: 3–4 hafta</li></ul>
        <h4>Neden biz?</h4><ul><li>20+ yıllık üretim deneyimi</li><li>80+ kişilik uzman ekip</li><li>Avrupa kalite standartlarında üretim</li><li>Zamanında teslimat garantisi</li><li>Lüks markalarla iş birliği deneyimi</li></ul>
        <h4>Markanız için güvenilir çözüm ortağı</h4><p>Kapsamlı üretim kapasitemiz ve detaylara verdiğimiz önem sayesinde, markalar için sadece kıyafet değil, aynı zamanda prestij üretiyoruz.</p>
        <h4>Vizyonumuz</h4><p>Dış giyim üretiminde güvenilir ve tercih edilen global bir üretici olmak. Üretim alanındaki 1. sınıf marka tekstil makinelerimizle kaliteden ödün vermeden çalışıyoruz.</p>
        <h4>Hizmetlerimiz</h4><ul><li><strong>Dış giyim üretimi:</strong> Etek, bluz, pantolon ve elbise üretiminde uzman kadro.</li><li><strong>Özel koleksiyon çözümleri:</strong> Markaların kimliğine uygun tasarım ve üretim desteği.</li><li><strong>Kumaş ve malzeme seçimi:</strong> Yüksek kaliteli, uzun ömürlü kumaş tedariki.</li><li><strong>Sürdürülebilir üretim:</strong> Çevreye duyarlı üretim süreçleri ve sorumlu tedarik zinciri.</li><li><strong>Toptan üretim kapasitesi:</strong> Lüks ve orta sınıf markalar için esnek ve güvenilir üretim.</li></ul>` },
      en: { t: "About Us", h: `<p class="lead">Founded in 2014 as a contract workshop and grown into an exporter through the experience it gained, EFA Hazır Giyim today operates with its own Planning, Pattern Room, Showroom, Cutting, Sewing and Pressing &amp; Packing departments together with trusted partners.</p>
        <p>EFA Hazır Giyim produces women's woven ready-to-wear: skirts, dresses, blouses, shirts, bustiers, jumpsuits, shorts and trousers.</p>
        <p>In 1,200 m² of covered space in Sultangazi, Istanbul, with more than 80 employees, our company has made customer benefit its core principle and always works with motivation and energy.</p>
        <h4>Production capacity</h4><p>A total of <strong>25,000 – 30,000 pieces</strong> per month. Monthly capacity by product:</p>
        <ul><li>Shorts / Trousers / Shirts: 15,000 – 20,000 pcs</li><li>Skirts / Blouses: 18,000 – 25,000 pcs</li><li>Bustiers: 15,000 – 25,000 pcs</li><li>Dresses: 15,000 – 20,000 pcs</li><li>Jumpsuits: 12,000 – 15,000 pcs</li></ul>
        <h4>Lead times</h4><ul><li>New collections: 8–10 weeks</li><li>Basic styles: 6–8 weeks</li><li>Repeat styles: 3–4 weeks</li></ul>
        <h4>Why us?</h4><ul><li>20+ years of production experience</li><li>An expert team of 80+</li><li>Production to European quality standards</li><li>On-time delivery guarantee</li><li>Experience working with luxury brands</li></ul>
        <h4>A reliable solution partner for your brand</h4><p>Thanks to our extensive capacity and attention to detail, we produce not just garments for brands, but prestige.</p>
        <h4>Our vision</h4><p>To be a trusted and preferred global manufacturer of ready-to-wear apparel. With first-class branded textile machinery on our production floor, we never compromise on quality.</p>
        <h4>What we do</h4><ul><li><strong>Apparel production:</strong> An expert team for skirts, blouses, trousers and dresses.</li><li><strong>Custom collection solutions:</strong> Design and production support tailored to each brand's identity.</li><li><strong>Fabric &amp; trim selection:</strong> Sourcing of high-quality, long-lasting fabrics.</li><li><strong>Sustainable production:</strong> Environmentally conscious processes and a responsible supply chain.</li><li><strong>Bulk production capacity:</strong> Flexible, reliable production for luxury and mid-market brands.</li></ul>` }
    },
    privacy: {
      tr: { t: "Gizlilik Politikası ve KVKK Aydınlatma Metni", h: `<p>EFA Hazır Giyim ("Şirket") olarak, 6698 sayılı Kişisel Verilerin Korunması Kanunu ("KVKK") kapsamında veri sorumlusu sıfatıyla kişisel verilerinizin güvenliğine önem veriyoruz. Bu metin, internet sitemiz aracılığıyla toplanan kişisel verilerin nasıl işlendiğini açıklar.</p>
        <h4>1. İşlenen kişisel veriler</h4><ul><li>Kimlik ve iletişim bilgileri: ad soyad, firma adı, e-posta adresi, telefon numarası</li><li>Talep bilgileri: teklif ve iletişim formlarına yazdığınız mesaj, ürün ve adet bilgileri</li><li>İşlem güvenliği bilgileri: IP adresi, tarayıcı ve ziyaret bilgileri (sunucu kayıtları)</li></ul>
        <h4>2. İşleme amaçları</h4><ul><li>Teklif ve bilgi taleplerinize yanıt vermek, sizinle iletişime geçmek</li><li>Ticari ilişkinin kurulması ve yürütülmesi</li><li>İnternet sitesinin güvenliğinin sağlanması</li><li>Yasal yükümlülüklerin yerine getirilmesi</li></ul>
        <h4>3. Hukuki sebepler</h4><p>Kişisel verileriniz; KVKK md. 5/2 kapsamında bir sözleşmenin kurulması veya ifası, hukuki yükümlülüklerin yerine getirilmesi ve temel hak ve özgürlüklerinize zarar vermemek kaydıyla Şirketimizin meşru menfaatleri hukuki sebeplerine dayanılarak işlenir.</p>
        <h4>4. Aktarım</h4><p>Kişisel verileriniz satılmaz ve pazarlama amacıyla üçüncü kişilerle paylaşılmaz. Yalnızca hizmet aldığımız barındırma (hosting) ve e-posta hizmet sağlayıcılarıyla, hizmetin gerektirdiği ölçüde ve yetkili kamu kurumlarıyla yasal zorunluluk hâlinde paylaşılabilir.</p>
        <h4>5. Saklama süresi</h4><p>Veriler, işleme amacının gerektirdiği süre ve ilgili mevzuatta öngörülen süreler boyunca saklanır; süre sonunda silinir, yok edilir veya anonim hâle getirilir.</p>
        <h4>6. Haklarınız</h4><p>KVKK md. 11 uyarınca; kişisel verilerinizin işlenip işlenmediğini öğrenme, bilgi talep etme, düzeltilmesini veya silinmesini isteme, aktarıldığı kişileri öğrenme, itiraz etme ve zararın giderilmesini talep etme haklarına sahipsiniz.</p>
        <h4>7. Başvuru</h4><p>Taleplerinizi <a href="mailto:${MAIL}">${MAIL}</a> adresine e-posta ile iletebilirsiniz. Başvurunuz en geç 30 gün içinde ücretsiz olarak yanıtlanır.</p>
        <p class="upd">Son güncelleme: ${UPD}</p>` },
      en: { t: "Privacy Policy", h: `<p>As EFA Hazır Giyim ("Company"), we act as data controller under the Turkish Personal Data Protection Law No. 6698 ("KVKK") and take the security of your personal data seriously. This policy explains how personal data collected through our website is processed.</p>
        <h4>1. Data we process</h4><ul><li>Identity and contact details: name, company, e-mail address, phone number</li><li>Request details: the message, product and quantity information you enter in our quote and contact forms</li><li>Security data: IP address, browser and visit information (server logs)</li></ul>
        <h4>2. Purposes</h4><ul><li>Responding to your quote and information requests and contacting you</li><li>Establishing and managing a business relationship</li><li>Keeping the website secure</li><li>Complying with legal obligations</li></ul>
        <h4>3. Legal grounds</h4><p>Your data is processed under KVKK Art. 5/2 for entering into or performing a contract, complying with legal obligations, and the Company's legitimate interests, provided your fundamental rights and freedoms are not harmed.</p>
        <h4>4. Transfers</h4><p>Your personal data is never sold or shared with third parties for marketing. It may only be shared with our hosting and e-mail service providers to the extent required for the service, and with authorised public bodies where legally required.</p>
        <h4>5. Retention</h4><p>Data is kept for as long as the purpose requires and for the periods set by law, after which it is deleted, destroyed or anonymised.</p>
        <h4>6. Your rights</h4><p>Under KVKK Art. 11 you may ask whether your data is processed, request information, ask for correction or deletion, learn the recipients, object, and claim compensation for damages.</p>
        <h4>7. Contact</h4><p>Please send your requests to <a href="mailto:${MAIL}">${MAIL}</a>. We reply free of charge within 30 days at the latest.</p>
        <p class="upd">Last updated: ${UPD}</p>` }
    },
    cookies: {
      tr: { t: "Çerez Politikası", h: `<p>Bu politika, efahazirgiyim.com internet sitesinde kullanılan çerezler ve benzeri teknolojiler hakkında sizi bilgilendirmek amacıyla hazırlanmıştır.</p>
        <h4>Çerez nedir?</h4><p>Çerezler, bir internet sitesini ziyaret ettiğinizde tarayıcınıza kaydedilen küçük metin dosyalarıdır. Sitenin düzgün çalışmasını ve tercihlerinizin hatırlanmasını sağlar.</p>
        <h4>Hangi çerezleri kullanıyoruz?</h4><ul><li><strong>Zorunlu çerezler:</strong> Sitenin güvenli ve hızlı çalışması için gereklidir (ör. sunucu ve önbellek çerezleri).</li><li><strong>Tercih kayıtları:</strong> Seçtiğiniz dil (TR/EN) ve çerez bildirimini onayladığınız bilgisi tarayıcınızda saklanır.</li></ul>
        <p>Sitemizde şu anda reklam, hedefleme veya pazarlama amaçlı çerez kullanılmamaktadır.</p>
        <h4>Üçüncü taraf hizmetler</h4><p>Yazı tipleri Google Fonts üzerinden, fabrika konum haritası Google Haritalar üzerinden yüklenir; bu sırada IP adresiniz Google'a iletilebilir ve Google kendi çerezlerini kullanabilir. Bazı tanıtım görselleri Unsplash üzerinden yüklenir. WhatsApp, LinkedIn ve Instagram bağlantılarına tıkladığınızda ilgili platformların kendi çerez politikaları geçerli olur.</p>
        <h4>Çerezleri nasıl yönetebilirsiniz?</h4><p>Tarayıcınızın ayarlarından çerezleri silebilir veya engelleyebilirsiniz. Zorunlu çerezleri engellemeniz durumunda sitenin bazı bölümleri düzgün çalışmayabilir.</p>
        <h4>İletişim</h4><p>Sorularınız için: <a href="mailto:${MAIL}">${MAIL}</a></p>
        <p class="upd">Son güncelleme: ${UPD}</p>` },
      en: { t: "Cookie Policy", h: `<p>This policy explains the cookies and similar technologies used on efahazirgiyim.com.</p>
        <h4>What are cookies?</h4><p>Cookies are small text files saved in your browser when you visit a website. They help the site work properly and remember your preferences.</p>
        <h4>Which cookies do we use?</h4><ul><li><strong>Strictly necessary cookies:</strong> required for the site to work securely and quickly (e.g. server and cache cookies).</li><li><strong>Preference records:</strong> your chosen language (TR/EN) and whether you accepted the cookie notice are stored in your browser.</li></ul>
        <p>We currently do not use advertising, targeting or marketing cookies.</p>
        <h4>Third-party services</h4><p>Fonts are loaded from Google Fonts and the factory map from Google Maps; Google may receive your IP address and use its own cookies. Some illustrative images are loaded from Unsplash. When you click the WhatsApp, LinkedIn or Instagram links, those platforms' own cookie policies apply.</p>
        <h4>Managing cookies</h4><p>You can delete or block cookies in your browser settings. If you block strictly necessary cookies, some parts of the site may not work properly.</p>
        <h4>Contact</h4><p>Questions: <a href="mailto:${MAIL}">${MAIL}</a></p>
        <p class="upd">Last updated: ${UPD}</p>` }
    }
  };
  const root = document.body;
  const mdl = root.querySelector("#mdl"), mb = root.querySelector("#mdlBody");
  const L = () => (document.documentElement.lang === "en" ? "en" : "tr");
  const esc = s => String(s).replace(/[&<>"]/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));
  let cur = null;
  function openModal(html) { mb.innerHTML = html; wireImgs(mb); mdl.classList.add("open"); mdl.setAttribute("aria-hidden", "false"); document.body.style.overflow = "hidden"; mdl.scrollTop = 0; }
  function closeModal() { mdl.classList.remove("open"); mdl.setAttribute("aria-hidden", "true"); document.body.style.overflow = ""; cur = null; }
  function stepHtml(i) {
    const s = STEPS[i], c = s[L()], en = L() === "en";
    const icon = root.querySelectorAll(".step .ic")[i].innerHTML;
    // Fotoğraf yoksa yerine bölümün ikonlu, animasyonlu tanıtım kartı görünür (boş/yarım görüntü olmaz)
    const gal = Array.from({ length: PHOTO_COUNT }, (_, n) => { const u = `assets/img/bolumler/${s.k}-${n + 1}.jpg${IMGV}`;
      const phd = `<div class="ph ill v${n}"><span class="ill-ic">${icon}</span><b>${esc(c.b[n])}</b><i class="ill-st"></i></div>`;
      return `<figure>${phd}<a href="${u}" target="_blank" rel="noopener"><img src="${u}"${(STOCK[s.k] || [])[n] ? ` data-remote="${stockUrl(STOCK[s.k][n])}"` : ""} alt="${esc(c.t)} ${n + 1}" loading="lazy"></a></figure>`; }).join("");
    return `<div class="mh"><div class="ic">${icon}</div><div><small>${String(i + 1).padStart(2, "0")} / 08</small><h3>${esc(c.t)}</h3></div></div>
      <div class="mb"><p class="lead">${esc(c.lead)}</p>${c.p.map(x => `<p>${esc(x)}</p>`).join("")}
      <ul class="bul">${c.b.map(x => `<li>${esc(x)}</li>`).join("")}</ul><div class="gal">${gal}</div></div>
      <div class="mf"><div class="nav2"><button type="button" data-go="${(i + 7) % 8}">← ${esc(STEPS[(i + 7) % 8][L()].t)}</button><button type="button" data-go="${(i + 1) % 8}">${esc(STEPS[(i + 1) % 8][L()].t)} →</button></div>
<a class="cta" href="#quote" data-close="1">${en ? "Get a Quote" : "Teklif Al"} →</a></div>`;
  }
  function openStep(i) { cur = { type: "step", i: i }; openModal(stepHtml(i)); }
  function openDoc(k) { cur = { type: "doc", k: k }; const d = DOCS[k][L()]; openModal(`<div class="mh"><div><small>EFA HAZIR GİYİM</small><h3>${esc(d.t)}</h3></div></div><div class="doc">${d.h}</div>`); }
  root.querySelectorAll(".step[data-step]").forEach((el, i) => {
    el.addEventListener("click", () => openStep(i));
    el.addEventListener("keydown", e => { if (e.key === "Enter" || e.key === " ") { e.preventDefault(); openStep(i); } });
  });
  root.addEventListener("click", e => {
    const d = e.target.closest("[data-doc]"); if (d) { e.preventDefault(); openDoc(d.dataset.doc); return; }
    const g = e.target.closest("[data-go]"); if (g) { openStep(+g.dataset.go); return; }
    if (e.target.closest("[data-close]")) closeModal();
  });
  mdl.addEventListener("click", e => { if (e.target === mdl || e.target.closest(".mdl-x")) closeModal(); });
  document.addEventListener("keydown", e => { if (e.key === "Escape" && mdl.classList.contains("open")) closeModal(); });
  // Dil değişince açık pencere yeniden çizilir / Re-render the open window when the language changes
  root.querySelectorAll(".lang button").forEach(b => b.addEventListener("click", () => { if (!cur) return; cur.type === "step" ? openStep(cur.i) : openDoc(cur.k); }));
  // Çerez bildirimi / Cookie notice
  const ck = root.querySelector("#ck");
  let ok = false; try { ok = localStorage.getItem("efaCookieOk") === "1"; } catch (e) {}
  if (!ok) ck.classList.add("show");
  root.querySelector("#ckOk").addEventListener("click", () => { ck.classList.remove("show"); try { localStorage.setItem("efaCookieOk", "1"); } catch (e) {} });


})();
