<?php
// EFA Hazır Giyim — teklif formu: talebi e-postayla gönderir ve panelde "Gelen Teklifler"e kaydeder
declare(strict_types=1);
define('EFA', 1);
require __DIR__ . '/yonetim/inc/lib.php';
header('Content-Type: application/json; charset=utf-8');
header('X-Robots-Tag: noindex');
header('Cache-Control: no-store');

function reply(int $code, bool $ok, string $tr = '', string $en = ''): void {
    http_response_code($code);
    echo json_encode(['ok' => $ok, 'tr' => $tr, 'en' => $en], JSON_UNESCAPED_UNICODE);
    exit;
}
if ($_SERVER['REQUEST_METHOD'] !== 'POST') reply(405, false, 'Geçersiz istek.', 'Invalid request.');
$origin = (string)($_SERVER['HTTP_ORIGIN'] ?? '');
if ($origin !== '') {
    $oh = strtolower((string)parse_url($origin, PHP_URL_HOST));
    $hh = strtolower(preg_replace('/:\d+$/', '', (string)($_SERVER['HTTP_HOST'] ?? '')));
    if ($oh !== $hh) reply(403, false, 'Geçersiz kaynak.', 'Invalid origin.');
}
// Robot tuzakları: görünmez alan dolu ya da form çok hızlı gönderildiyse sessizce "tamam" de
if (trim((string)($_POST['website'] ?? '')) !== '') reply(200, true);
$ts = (int)($_POST['ts'] ?? 0);
if ($ts > 0 && (int)(microtime(true) * 1000) - $ts < 3000) reply(200, true);

$f = [
    'ad'    => txt($_POST['ad'] ?? '', 80),
    'firma' => txt($_POST['firma'] ?? '', 100),
    'eposta'=> txt($_POST['eposta'] ?? '', 120),
    'tel'   => txt($_POST['tel'] ?? '', 30),
    'grup'  => txt($_POST['grup'] ?? '', 80),
    'adet'  => txt($_POST['adet'] ?? '', 40),
    'mesaj' => txt($_POST['mesaj'] ?? '', 2000),
];
$lang = ($_POST['lang'] ?? '') === 'en' ? 'en' : 'tr';
if ($f['ad'] === '' || $f['firma'] === '' || $f['eposta'] === '') reply(400, false, 'Lütfen ad, firma ve e-posta alanlarını doldurun.', 'Please fill in name, company and e-mail.');
if (!filter_var($f['eposta'], FILTER_VALIDATE_EMAIL)) reply(400, false, 'E-posta adresi geçerli değil.', 'The e-mail address is not valid.');
if (empty($_POST['kvkk'])) reply(400, false, 'Lütfen KVKK metnini onaylayın.', 'Please confirm the privacy notice.');

// Aynı adresten saatte en fazla 5 gönderim
ensure_dir(DATA_DIR, true);
$rf = DATA_DIR . '/form_rate.php';
$rate = jread($rf, []);
$now = time();
foreach ($rate as $ip => $list) { $rate[$ip] = array_values(array_filter((array)$list, function ($t) use ($now) { return $now - (int)$t < 3600; })); if (!$rate[$ip]) unset($rate[$ip]); }
$mine = $rate[client_ip()] ?? [];
if (count($mine) >= 5) reply(429, false, 'Çok fazla gönderim yapıldı. Lütfen biraz sonra tekrar deneyin ya da WhatsApp ile yazın.', 'Too many requests. Please try again later or use WhatsApp.');
$mine[] = $now; $rate[client_ip()] = $mine;
jwrite($rf, $rate, true);

// Panelde saklanır (son 500 talep)
$ib = DATA_DIR . '/teklifler.php';
$inbox = jread($ib, []);
$item = $f + ['id' => bin2hex(random_bytes(6)), 'tarih' => date('c'), 'dil' => $lang, 'ip' => client_ip()];
array_unshift($inbox, $item);
$inbox = array_slice($inbox, 0, 500);
jwrite($ib, $inbox, true);

// E-posta: alıcı panelde "İletişim"teki adres
$content = jread(CONTENT_FILE, []);
$to = (string)($content['c']['email'] ?? '');
if (!filter_var($to, FILTER_VALIDATE_EMAIL)) $to = 'ezgi.cubukcu@efahazirgiyim.com';
$host = strtolower(preg_replace('/^www\./', '', preg_replace('/:\d+$/', '', (string)($_SERVER['HTTP_HOST'] ?? 'efahazirgiyim.com'))));
if (!preg_match('/^[a-z0-9.-]+\.[a-z]{2,}$/', $host)) $host = 'efahazirgiyim.com';
$from = 'noreply@' . $host;
$clean = function (string $s): string { return trim(str_replace(["\r", "\n", "%0a", "%0d"], ' ', $s)); };
$subject = 'Yeni teklif talebi — ' . $clean($f['firma']);
$encSubject = '=?UTF-8?B?' . base64_encode($subject) . '?=';
$body = "Web sitenizden yeni bir teklif talebi geldi.\n\n"
    . "Ad Soyad : {$f['ad']}\nFirma    : {$f['firma']}\nE-posta  : {$f['eposta']}\nTelefon  : {$f['tel']}\n"
    . "Ürün grubu: {$f['grup']}\nTahmini adet: {$f['adet']}\nDil      : " . strtoupper($lang) . "\n\nMesaj:\n{$f['mesaj']}\n\n"
    . "— Bu talep ayrıca Yönetim Paneli > Gelen Teklifler bölümünde saklanmıştır.\n"
    . "Yanıtlamak için bu e-postayı doğrudan yanıtlayabilirsiniz.\n";
$headers = implode("\r\n", [
    'From: =?UTF-8?B?' . base64_encode('EFA Web Sitesi') . '?= <' . $from . '>',
    'Reply-To: ' . $clean($f['eposta']),
    'MIME-Version: 1.0',
    'Content-Type: text/plain; charset=UTF-8',
    'Content-Transfer-Encoding: 8bit',
    'X-Mailer: EFA-Site',
]);
$sent = false;
if (function_exists('mail')) {
    $sent = @mail($to, $encSubject, $body, $headers, '-f' . $from);
    if (!$sent) $sent = @mail($to, $encSubject, $body, $headers);
}
// E-posta gitmese bile talep panelde kayıtlı olduğu için kullanıcıya başarı gösterilir
reply(200, true);
